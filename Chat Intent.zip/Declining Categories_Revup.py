import sys
import json
import pyodbc
import datetime
from babel import Locale
from babel.numbers import format_number, format_decimal, format_percent

#ip = '{"State":"Tamil Nadu"}'

input_user=json.loads(sys.argv[1])
#input_user=json.loads(ip)
def DecliningCategories(State):
    ## pass the name of state as input to the function     
        conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                                                  'Server=52.172.25.188;'
                                                  'Database=RevUpData;'
                                                  "UID=RevUpUser;"
                                                  "PWD=UgyuTR676567r7%$Rfy&^5yjgu78;"
                                                  "Trusted_Connection=no;")
        query = '''SELECT TOP 10 Category,[Current Month],[Last 6 Month Average],Percentage 
                    FROM Declining_Categories WHERE State = '{0}' AND Percentage < 0
                    ORDER BY Percentage;'''
        
        cursor = conn.cursor()
        number_of_rows = cursor.execute(query.format(State))
        html_content="Category|Current Month|Last 6 Month Average|Percentage"
        result = cursor.fetchall()
        
        for row in result:
                html_content=html_content+"\n "+str(row[0])+"|"+str(row[1])+"|"+str(row[2])+"|"+str(row[3])
        FinalString2 = str("Declining Category:")
        output={'data':[{'type': 'MESSAGE','result': FinalString2},{'type':'INSIGHTS','result':[{'Title':'','Subtitle':'','ChartData':html_content,'ChartType':'table'}]}]}
        return json.dumps(output)
#calling the function for insights
State = input_user["State"]

#stateName="Jharkhand"
input = sys.argv[1]
print(DecliningCategories(State))
