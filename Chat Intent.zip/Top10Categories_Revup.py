
import sys
import json
import pyodbc
import datetime
from babel import Locale
from babel.numbers import format_number, format_decimal, format_percent

#ip = '{"Territory":"TNA","Month":"March","Year":"2020"}'

input_user=json.loads(sys.argv[1])
#input_user=json.loads(ip)
def TopCategories(Territory,Month,Year):
    ## pass the name of state as input to the function     
        conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                                                  'Server=52.172.25.188;'
                                                  'Database=Revupdata;'
                                                  "UID=RevUpUser;"
                                                  "PWD=UgyuTR676567r7%$Rfy&^5yjgu78;"
                                                  "Trusted_Connection=no;")
        query = '''select  TOP 10 
                    A.Distributor_Territory AS [Distributor Territory],
                    'FY' + CAST(A.Fiscal_Year_Full%100 -2 AS VARCHAR) + '-' + CAST(A.Fiscal_Year_Full%100 -1 AS VARCHAR) AS [Fiscal Year],
                    A.Month,
                    A.Part_Category AS Category,
                    ROUND(A.Primary_Sales,2) AS [Primary Sales],
                    ROUND(A.Secondary_Sales,2) AS [Secondary Sales]
                    from TOP_10_Categories A
                    where Distributor_Territory = '{0}'
                    AND Month = '{1}'
                    AND Year = {2} + 1
                    ORDER BY [Secondary Sales] DESC;'''
        
        cursor = conn.cursor()
        number_of_rows = cursor.execute(query.format(Territory,Month,Year))
        html_content="Distributor Territory|Fiscal Year|Month|Category|Primary Sales|Secondary Sales"
        result = cursor.fetchall()
        
        for row in result:
                html_content=html_content+"\n "+str(row[0])+"|"+str(row[1])+"|"+str(row[2])+"|"+str(row[3])+"|"+str(row[4])+"|"+str(row[5])
        FinalString2 = str("Top 10 Category:")
        output={'data':[{'type': 'MESSAGE','result': FinalString2},{'type':'INSIGHTS','result':[{'Title':'','Subtitle':'','ChartData':html_content,'ChartType':'table'}]}]}
        return json.dumps(output)
#calling the function for insights
#Territory,Month,Year
Territory = input_user["Territory"]
Month = input_user["Month_Nm"]
Year = input_user["Year_No"]

#stateName="Jharkhand"
print(TopCategories(Territory,Month,Year))

