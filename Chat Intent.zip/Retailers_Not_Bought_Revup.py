import sys
import json
import pyodbc
import datetime
from babel import Locale
from babel.numbers import format_number, format_decimal, format_percent

#ip = '{"State":"Tamil Nadu"}'

input_user=json.loads(sys.argv[1])
#input_user=json.loads(ip)
def RetailerNotBought(State):
    ## pass the name of state as input to the function     
        conn = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};'
                                                  'Server=52.172.25.188;'
                                                  'Database=RevUpData;'
                                                  "UID=RevUpUser;"
                                                  "PWD=UgyuTR676567r7%$Rfy&^5yjgu78;"
                                                  "Trusted_Connection=no;")
        query = '''select top 25 State,ContactCode,ContactName, ROUND(Last_6_Months_Sales,2) AS Last_6_Months_Sales from retailers_not_bought where state = UPPER('{0}') order by 4 desc'''
        
        cursor = conn.cursor()
        number_of_rows = cursor.execute(query.format(State))
        html_content="State|Retailer Code|Retailer|Last 6 Month Average"
        result = cursor.fetchall()
        
        for row in result:
                html_content=html_content+"\n "+str(row[0])+"|"+str(row[1])+"|"+str(row[2])+"|"+str(row[3])
        FinalString2 = str("Retailers Who Have Not Bought:")
        output={'data':[{'type': 'MESSAGE','result': FinalString2},{'type':'INSIGHTS','result':[{'Title':'','Subtitle':'','ChartData':html_content,'ChartType':'table'}]}]}
        return json.dumps(output)
#calling the function for insights
State = input_user["State"]

#stateName="Jharkhand"
input = sys.argv[1]
print(RetailerNotBought(State))
