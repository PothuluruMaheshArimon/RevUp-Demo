let exactView ='';
let dirllTypeView='';
let sharedTestData=null;

let stateGen ='';
let distrubuteLevelTotal = false;
let districtLevelTotal = false;
var terryReqObj;
var drillStatus=''
var singleSection = false;

let singleStateValue;
let singleTerryValue;
let singleDistyValue;
function stateGeneralDataFromApi(stateGen) {
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (terryReqObj) {
        terryReqObj.abort();
        terryReqObj = null;
    }
    let currentPage = "State";
    exactView = "stateView";
    if(stateGen == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
    let terryFilterData;
    if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
        terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
    }else{
        terryFilterData = createGeneralFilterData();
    }
    let procedureName = "General_View_State_Table_V2";
    terryReqObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
      //  data: JSON.stringify({ 'filter': "General_View_State_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            generalTotalStatesDataFromApi(data,currentPage,stateGen)
            terryReqObj = null;
            data = null;
        }),
        error: (function (err) {
            terryReqObj = null;
            console.log(err);
        })
    });
}

var terryDrillReqObj;
function generalterriDrillDataFromApi(stateGen){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "Territory";
    exactView = "territoryView";
    if(stateGen == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (terryDrillReqObj) {
            terryDrillReqObj.abort();
            terryDrillReqObj = null;
        }
        let terryFilterData;
        if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
            terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
        }else{
            terryFilterData = createGeneralFilterData();
        }
        let procedureName = "General_View_Territory_Table_V2";
        terryDrillReqObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
            //data: JSON.stringify({ 'filter': "General_View_Territory_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
               generalTotalStatesDataFromApi(data,currentPage,stateGen);
                terryDrillReqObj = null;
                data = null;
            }),
            error: (function (err) {
                terryDrillReqObj = null;
                console.log(err);
            })
        });
}

var distributeDrillReqObj;
function generalDistyDrillDataFromApi(stateGen){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
        if (distributeDrillReqObj) {
            distributeDrillReqObj.abort();
            distributeDrillReqObj = null;
        }
        let currentPage = "Distributers";
        exactView = "distributerView";
        if(stateGen == "SecondLevel"){
            dirllTypeView = "SecondLevel";
        }else{
            dirllTypeView='';
        }
        let terryFilterData;
        if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
            terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
        }else{
            terryFilterData = createGeneralFilterData();
        }
        let procedureName = "General_View_Distributor_Table_V2";
        distributeDrillReqObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
     //       data: JSON.stringify({ 'filter': "General_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                generalTotalStatesDataFromApi(data,currentPage,stateGen)
                distributeDrillReqObj = null;
                data = null;
            }),
            error: (function (err) {
                distributeDrillReqObj = null;
                console.log(err);
            })
        });
}

let districtDrillReqObj;
function generalDistictDrillDataFromApi(stateGen){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "District";
    exactView = "districtView";
    if(stateGen == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (districtDrillReqObj) {
            districtDrillReqObj.abort();
            districtDrillReqObj = null;
        }
        let terryFilterData;
        if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
            terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
        }else{
            terryFilterData = createGeneralFilterData();
        }
        let procedureName = "General_View_District_Table_V2";
        districtDrillReqObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
           // data: JSON.stringify({ 'filter': "General_View_District_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                generalTotalStatesDataFromApi(data,currentPage,stateGen)
                districtDrillReqObj = null;
                data = null;
            }),
            error: (function (err) {
                districtDrillReqObj = null;
                console.log(err);
            })
        });

}



var geneTotalReqObj;
function generalTotalStatesDataFromApi(data,currentPage,stateGen){
        if (geneTotalReqObj) {
            geneTotalReqObj.abort();
            geneTotalReqObj = null;
        }
        let terryFilterData;
        if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
            terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
        }else{
            terryFilterData = createGeneralFilterData();
        }
        let procedureName = "General_View_State_Total_V2";
        geneTotalReqObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
     //       data: JSON.stringify({ 'filter': "General_View_State_Total_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let dataSum = resultData.data.data[0];
                if(stateGen == "SecondLevel" && currentPage == "Territory"){
                    territoryTotalFetching(data,dataSum,currentPage,stateGen);
                }else if(stateGen == "SecondLevel" && currentPage == "Distributers"){
                    territoryTotalFetching(data,dataSum,currentPage,stateGen);
                }else if(stateGen == "SecondLevel" && currentPage == "District"){
                    territoryTotalFetching(data,dataSum,currentPage,stateGen);
                }else{
                 generalDataToInsertTable(data,dataSum,currentPage,stateGen);
                }
                geneTotalReqObj = null;
                data = null;
            }),
            error: (function (err) {
                geneTotalReqObj = null;
                console.log(err);
            })
        });
}

let terryReqObjTotal;
function territoryTotalFetching(data,dataSum,currentPage,stateGen){
    if (terryReqObjTotal) {
        terryReqObjTotal.abort();
        terryReqObjTotal = null;
    }
    let terryFilterData;
    if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
        terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
    }else{
        terryFilterData = createGeneralFilterData();
    }
    let procedureName = "General_View_State_Table_V2";
    terryReqObjTotal = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
     //   data: JSON.stringify({ 'filter': "General_View_State_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataTerrySum = resultData.data.data[0];
            if(stateGen == "SecondLevel" && currentPage == "Distributers"){
                distributerTotalFetching(data,dataSum,currentPage,stateGen,dataTerrySum);
            }else if(stateGen == "SecondLevel" && currentPage == "District"){
                distributerTotalFetching(data,dataSum,currentPage,stateGen,dataTerrySum);
            }else{
                generalDataToInsertTable(data,dataSum,currentPage,stateGen,dataTerrySum);
            }
            terryReqObjTotal = null;
            data = null;
        }),
        error: (function (err) {
            terryReqObjTotal = null;
            console.log(err);
        })
    });
}

let distryReqObjTotal;
function distributerTotalFetching(data,dataSum,currentPage,stateGen,dataTerrySum){
    if (distryReqObjTotal) {
        distryReqObjTotal.abort();
        distryReqObjTotal = null;
    }
    let terryFilterData;
    if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
        terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
    }else{
        terryFilterData = createGeneralFilterData();
    }
    let procedureName = "General_View_Territory_Table_V2";
    distryReqObjTotal = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
     //   data: JSON.stringify({ 'filter': "General_View_Territory_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataDistrySum = resultData.data.data[0];
            if(stateGen == "SecondLevel" && currentPage == "District"){
                districtTotalFetching(data,dataSum,currentPage,stateGen,dataTerrySum,dataDistrySum);
            }else {
                generalDataToInsertTable(data,dataSum,currentPage,stateGen,dataTerrySum,dataDistrySum);
            }
            distryReqObjTotal = null;
            data = null;
        }),
        error: (function (err) {
            distryReqObjTotal = null;
            console.log(err);
        })
    });
}

let distritObjTotal;
function districtTotalFetching(data,dataSum,currentPage,stateGen,dataTerrySum,dataDistrySum){
    if (distritObjTotal) {
        distritObjTotal.abort();
        distritObjTotal = null;
    }
    let terryFilterData;
    if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
        terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
    }else{
        terryFilterData = createGeneralFilterData();
    }
    let procedureName = "General_View_Distributor_Table_V2";
    distritObjTotal = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
     
     //   data: JSON.stringify({ 'filter': "General_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataDistrictSum = resultData.data.data[0];
            generalDataToInsertTable(data,dataSum,currentPage,stateGen,dataTerrySum,dataDistrySum,dataDistrictSum);
            distritObjTotal = null;
            data = null;
        }),
        error: (function (err) {
            distritObjTotal = null;
            console.log(err);
        })
    });
}

let distryOnlyObj;
function generalDistyOnlyDrillDataFromApi(stateGen){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
        if (distryOnlyObj) {
            distryOnlyObj.abort();
            distryOnlyObj = null;
        }
        let currentPage = "Distributers";
        exactView = "distributerView";
        if(stateGen == "SecondLevel"){
            dirllTypeView = "SecondLevel";
        }else{
            dirllTypeView='';
        }
        let terryFilterData;
        if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
            terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
        }else{
            terryFilterData = createGeneralFilterData();
        }
        let procedureName = "General_View_Distributor_Only_Table_V2";
        distryOnlyObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "General_View_Distributor_Only_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                generalTotalStatesDataFromApi(data,currentPage,stateGen)
                distributeDrillReqObj = null;
                data = null;
            }),
            error: (function (err) {
                distryOnlyObj = null;
                console.log(err);
            })
        });
}

let distictOnlyObj;
function generalDistictOnlyDrillDataFromApi(){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "District";
    exactView = "districtView";
    if(stateGen == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (distictOnlyObj) {
            distictOnlyObj.abort();
            distictOnlyObj = null;
        }
        let terryFilterData;
        if(stateGen != undefined && stateGen != "" && stateGen != "SecondLevel"){
            terryFilterData =  createGeneralDrillDownFilterData(stateGen,currentPage);
        }else{
            terryFilterData = createGeneralFilterData();
        }
        let procedureName = "General_View_District_Only_Table_V2";
        distictOnlyObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "General_View_District_Only_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                generalTotalStatesDataFromApi(data,currentPage,stateGen)
                districtDrillReqObj = null;
                data = null;
            }),
            error: (function (err) {
                distictOnlyObj = null;
                console.log(err);
            })
        });
}

function generalDataToInsertTable(data,dataSum,currentPage,stateGen,dataTerrySum,dataDistrySum,dataDistrictSum){
    let htmlString = '';
    if(data.length != 0){
        if(stateGen != "" && stateGen != undefined){
            if(stateGen == "SecondLevel"){
                secondLevelTotal = true;      
                if(currentPage == "Territory"){
                    drillStatus='terryLevel'
                    singleSection = false
                    let currState = data[0].State;
                    let stateValue = data[0].State;
                  
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="   text-align: center;" class=" auto">State</th>';
                   for(let i=0; i < data.length; i++){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th   >  </th>';
                        currState = data[i].State;
                        stateValue = data[i].State
                    }

                    if(stateValue != ""){
                        htmlString +='<th style="border-right: aliceblue; text-align: center;">'+stateValue+'</th>'; 
                    }else{
                        htmlString +='<th   ></th>'
                    }
                    stateValue = "";
                        if(i == data.length-1){
                            htmlString += '<th   >  </th>';
                          }
                    }

                    htmlString +='<th rowspan="2" style="cursor:none;">TOTAL</th></tr><tr> <th style="text-align: center;     " class=" auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="stateGeneralDataFromApi()"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="generalDistyDrillDataFromApi(\'' + serSecDrill + '\')"></i></th>';
                    currState = data[0].State;
                    for(let i=0; i < data.length; i++){
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                            htmlString += '<th> TOTAL </th>';
                            currState = data[i].State;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor_Territory + '</a></th>';
                          if(i == data.length-1){
                            htmlString += '<th> TOTAL </th>';
                          }
                    }
                    
                }
				else if(currentPage == "Distributers"){

                    drillStatus = "distryLevel";
                    singleSection = false
                    sharedTestData=null;
                    sharedTestData=data;
                    let currState = data[0].State;
                    let currterr = data[0].Distributor_Territory;
                    let compare = currState+currterr;
                    distrubuteLevelTotal = true;
                    let stateValue = data[0].State;
                   
                    
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" >';
                    htmlString += '<thead>';
                    htmlString += '<tr>';
                    htmlString += '<th style=" border-right: aliceblue;text-align: center;" class=" auto">State</th>';
                    let distCompar;
                    for(let i=0; i < data.length; i++){
                        distCompar = data[i].State+data[i].Distributor_Territory
                    if(compare.toLowerCase() != (distCompar).toLowerCase()){
                         htmlString += '<th style="    border: none;   ">  </th>';                      
                         compare = data[i].State+data[i].Distributor_Territory;
                    }
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th style="    border: none;   ">  </th>';      
                        currState = data[i].State;
                        stateValue = data[i].State;
                   }
                   if(stateValue != ""){
                        htmlString +='<th  style="border-right: hidden;" text-align: center;">'+currState+'</th>'; 
                   }else{
                    htmlString +='<th style="    border: none;  "></th>'; 
                   }  
                   stateValue ="";
                        if(i == data.length-1){                          
                            htmlString += '<th style="    border: none;  ">  </th>';
                         }
                    }

                    htmlString += '<th style="    border: none;  ">  </th>';
                    htmlString +='<th rowspan="4" style="cursor:none;">TOTAL </th>';
                    htmlString +='</tr>';
                    htmlString +='<tr>';
                    htmlString +='<th style="text-align: center;  " class=" auto">Territory</th>'
                    
                    currState = data[0].State;
                    currterr = data[0].Distributor_Territory;
                    let distriValue = data[0].Distributor_Territory;
                    compare = currState+currterr;
                    for(let i=0; i < data.length; i++){
                        
                        if(compare.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            compare = data[i].State+data[i].Distributor_Territory;
                            distriValue = data[i].Distributor_Territory;
                        }
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                             htmlString += '<th rowspan="3"> TOTAL </th>';
                            currState = data[i].State;
                        }
                            if(distriValue != ""){
                                htmlString += '<th style="border-right: hidden;""> <a>'+data[i].Distributor_Territory + '</a></th>';
                            }else{
                                htmlString += '<th style="    border: none;"></th>'
                            }
                          distriValue = "";
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none; ">  </th>'; 
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                          
                          }
                    }
                    htmlString +='<tr> <th style="text-align: center;     " class=" auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Up" id="partTerryDownId" onClick="generalterriDrillDataFromApi(\'' + serSecDrill + '\')"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="generalDistictDrillDataFromApi(\'' + serSecDrill + '\')"></i></th>';
                    currterr = data[0].State+data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                       
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                            
                            currterr = data[i].State+data[i].Distributor_Territory;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th rowspan="3"> TOTAL </th>';                           
                          }
                       
                    }
                  

                }
                else if(currentPage == "District"){

                    drillStatus = "districtLevel"
                    singleSection = false

                    let currState = data[0].State;
                    let currterr = currState+data[0].Distributor_Territory;
                    distrubuteLevelTotal = true;
                    districtLevelTotal = true;
                    let stateValue = data[0].State;
                    let currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                   
                    
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" >';
                    htmlString += '<thead>';
                    htmlString += '<tr>';
                    htmlString += '<th style=" border-right: aliceblue;text-align: center;" class=" auto">State</th>';
                   for(let i=0; i < data.length; i++){

                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<th style="    border: none;   ">  </th>';                      
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                   }

                    if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                         htmlString += '<th style="    border: none;   ">  </th>';                      
                        currterr = data[i].State+data[i].Distributor_Territory;
                    }
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th style="    border: none;   ">  </th>';      
                        currState = data[i].State;
                        stateValue = data[i].State;
                   }
                   if(stateValue != ""){
                        htmlString +='<th  style="border-right: hidden;" text-align: center;">'+currState+'</th>'; 
                   }else{
                    htmlString +='<th style="    border: none;  "></th>'; 
                   }  
                   stateValue ="";
                    if(i == data.length-1){        
                        htmlString += '<th style="    border: none;   ">  </th>';                   
                        htmlString += '<th style="    border: none;  ">  </th>';
                       }
                    }
                    
                    htmlString += '<th style="    border: none;  ">  </th>';
                    htmlString +='<th rowspan="4" style="cursor:none;">TOTAL </th>';
                    htmlString +='</tr>';
                    htmlString +='<tr>';
                    htmlString +='<th style="text-align: center;  " class=" auto">Territory</th>'
                    
                    currState = data[0].State;
                    currterr = data[0].State+data[0].Distributor_Territory;
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    let distriValue = data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                        
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                            distriValue = data[i].State+data[i].Distributor_Territory;
                        }
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                             htmlString += '<th rowspan="3"> TOTAL </th>';
                            currState = data[i].State;
                        }
                            if(distriValue != ""){
                                htmlString += '<th style="border-right: hidden;""> <a>'+data[i].Distributor_Territory + '</a></th>';
                            }else{
                                htmlString += '<th style="    border: none;"></th>'
                            }
                          distriValue = "";
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none;   ">  </th>'; 
                            htmlString += '<th style="    border: none; ">  </th>'; 
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                          
                          }
                    }
                    htmlString +='<tr> <th style="text-align: center;     " class=" auto"> &nbsp;&nbsp;&nbsp;&nbsp; Distributers &nbsp;&nbsp;&nbsp;&nbsp;</th>';
                    currterr = data[0].State+data[0].Distributor_Territory;
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    for(let i=0; i < data.length; i++){
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th> </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th rowspan="0"> TOTAL </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none;   ">  </th>'; 
                            htmlString += '<th rowspan="0"> TOTAL </th>';                           
                          }
                       
                    }
                    htmlString +='<tr> <th style="text-align: center;     " class=" auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Up" id="partTerryDownId" onClick="generalDistyDrillDataFromApi(\'' + serSecDrill + '\')"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp;</th>';
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    for(let i=0; i < data.length; i++){
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th rowspan="0"> TOTAL </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                          htmlString += '<th> <a>'+data[i].DistrictName + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th rowspan="0"> TOTAL </th>';                           
                          }
                       
                    }

                }
            }else{
            if(currentPage == "Territory"){
                drillStatus = "terryLevel"
                singleSection = true;
                singleStateValue = data[0].State;
                singleTerryValue = data[0].Distributor_Territory
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="   text-align: center;" class=" auto">State</th><th style="     text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr> <tr> <th style="cursor:none;text-align: center;     " class=" auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px; " title = "Drill Top" id="partDistryDownId" onClick="stateGeneralDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a onClick="generalDistyDrillDataFromApi(\'' + data[i].Distributor_Territory + '\')">'+data[i].Distributor_Territory + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            }
            else if(currentPage == "Distributers"){
                drillStatus = "distryLevel"
                singleSection = true
                singleStateValue = data[0].State;
                singleTerryValue = data[0].Distributor_Territory;
                singleDistyValue = data[0].DistributorID;
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="   text-align: center;" class=" auto">State</th><th style="     text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr>'; 
                htmlString +='<tr><th style="   text-align: center;" class=" auto">Territory</th><th style="     text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor_Territory+'</th></tr> <tr> <th style="cursor:none;text-align: center;     " class=" auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px; " title = "Drill Top" id="partDistryDownId" onClick="stateGeneralDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a onClick="generalDistictDrillDataFromApi(\'' + data[i].DistributorID + '\')">'+data[i].Distributor + '</a></th>';
                } 
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            } else if(currentPage == "District"){
                drillStatus = "districtLevel"
                singleSection = true
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="   text-align: center;" class=" auto">State</th><th style="     text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr>'; 
                htmlString +='<tr><th style="   text-align: center;" class=" auto">Territory</th><th style="     text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor_Territory+'</th></tr>';
                htmlString += '<tr><th style="   text-align: center;" class=" auto">Distributers</th><th style="     text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor+'</th></tr><tr> <th style="cursor:none;text-align: center;     " class=" auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px; " title = "Drill Top" id="partDistryDownId" onClick="stateGeneralDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th>'+data[i].DistrictName + '</a></th>';
                } 
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            } 
        }

        }else{
            if(currentPage == "State"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead> <tr> <th style="text-align: center; " class=" auto"> Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partTerryDownId" onClick="generalterriDrillDataFromApi()"></i> &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="generalterriDrillDataFromApi(\'' + serSecDrill + '\')"></i>  </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th style="    min-width: 12vw;"> <a onClick="generalterriDrillDataFromApi(\'' + data[i].State + '\')">'+data[i].State + '</a></th>';
                }
                htmlString +='<th style="cursor:none;    min-width: 12vw;">TOTAL</th>';
            }
            else if(currentPage == "Territory"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center; " class=" auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="stateGeneralDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partDistryDownId" onClick="generalDistyOnlyDrillDataFromApi()"></i> </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].Distributor_Territory + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>'; 
            }
            else if(currentPage == "Distributers"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center; " class=" auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="generalterriDrillDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partDistryDownId" onClick="generalDistictOnlyDrillDataFromApi()"></i>  </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>'; 
            }
            else if(currentPage == "District"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center; " class=" auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="generalDistyOnlyDrillDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp; </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].DistrictName + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            }
           
        }

        htmlString +='</tr><thead><tbody>'
    
        if(dataSum[0].Potential != null && dataSum[0].Potential != 0){
            htmlString +='<tr><td class=" auto">Addressability</td>';
            currState = data[0].State;
            let currterry = currState+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            let tt=0;
            let dd=0;
            let ds=0;
            for(let i=0; i < data.length; i++){

                let exactValue = data[i].Potential; 
                if(exactValue == null){
                    exactValue=0;
                }

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Potential) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                 

                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Potential) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                    }
                }
               
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Potential) + '</td></tr>';    
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Primary_Sales != null && dataSum[0].Primary_Sales != 0){
            htmlString +='<tr><td class=" auto">Sales</td>';
            currState = data[0].State;
            currterry = currState+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                 if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Primary_Sales) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++
                    }
                 }

                let exactValue = data[i].Primary_Sales; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Primary_Sales) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                    }
                }
            }

            htmlString +='<td> '+numberFormatter(dataSum[0].Primary_Sales) + '</td></tr>';
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Penetration != null && dataSum[0].Penetration != 0){
            htmlString +='<tr><td class=" auto">Market Share %</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Penetration) + '%</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].Penetration; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+convertValueInPersent(exactValue) + '%</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Penetration) + '%</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                    }
                }
            }

            htmlString +='<td> '+convertValueInPersent(dataSum[0].Penetration) + '%</td></tr>';
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Distributor_Count != null && dataSum[0].Distributor_Count != 0){
            htmlString +='<tr><td class=" auto"># Distributors</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Distributor_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }


                let exactValue = data[i].Distributor_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Distributor_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Distributor_Count) + '</td></tr>';
        }

        // tt=0;
        // dd=0;
        // ds=0;
        // if(dataSum[0].Dealer_Count != null && dataSum[0].Dealer_Count != 0){
        //     htmlString +='<tr><td class=" auto"># Dealers</td>'
        //     currState = data[0].State;
        //     currterry = data[0].State+data[0].Distributor_Territory;
        //     currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
        //     for(let i=0; i < data.length; i++){
                
        //         if(districtLevelTotal){
        //             if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Dealer_Count) + '</td>';
        //                 currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
        //                 ds++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Count) + '</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //         }

        //          if(distrubuteLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Count) + '</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //          }

        //          if(distrubuteLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }

        //          if(secondLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }


        //         let exactValue = data[i].Dealer_Count; 
        //         if(exactValue == null){
        //             exactValue=0;
        //         }
        //         htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
        //         if(districtLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Dealer_Count) + '</td>';
        //             }
        //         }

        //         if(distrubuteLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Count) + '</td>';
        //             }
        //         }

        //         if(secondLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //             }
        //         }
        //     }
        //     htmlString +='<td> '+numberFormatter(dataSum[0].Dealer_Count) + '</td></tr>';
        // }

        // tt=0;
        // dd=0;
        // ds=0;
        // if(dataSum[0].Dealer_Contribution != null && dataSum[0].Dealer_Contribution != 0){
        //     htmlString +='<tr><td class=" auto">Dealer Contribution To Sales</td>'
        //     currState = data[0].State;
        //     currterry = data[0].State+data[0].Distributor_Territory;
        //     currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
        //     for(let i=0; i < data.length; i++){


        //         if(districtLevelTotal){
        //             if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
        //                 htmlString += '<td> '+ convertValueInPersent(dataDistrictSum[ds].Dealer_Contribution) + '%</td>';
        //                 currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
        //                 ds++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+ convertValueInPersent(dataDistrySum[dd].Dealer_Contribution) + '%</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Contribution) + '%</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //         }

        //          if(distrubuteLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+ convertValueInPersent(dataDistrySum[dd].Dealer_Contribution) + '%</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //          }

        //          if(distrubuteLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Contribution) + '%</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }

        //          if(secondLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Contribution) + '%</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }

        //         let exactValue = convertValueInPersent(data[i].Dealer_Contribution); 
        //         if(exactValue == null){
        //             exactValue=0;
        //         }
        //         htmlString += '<td> '+ exactValue + '%</td>';
                
        //         if(districtLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+ convertValueInPersent(dataDistrictSum[ds].Dealer_Contribution) + '%</td>';
        //             }
        //         }

        //         if(distrubuteLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+ convertValueInPersent(dataDistrySum[dd].Dealer_Contribution) + '%</td>';
        //             }
        //         }

        //         if(secondLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Contribution) + '%</td>';
        //             }
        //         }
        //     }
        //     htmlString +='<td> '+ convertValueInPersent(dataSum[0].Dealer_Contribution) + '%</td></tr>';
        // }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Retailer_Count != null && dataSum[0].Retailer_Count != 0){
           htmlString +='<tr><td class=" auto"># Retailers</td>';
           currState = data[0].State;
           currterry = data[0].State+data[0].Distributor_Territory;
           currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Retailer_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].Retailer_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Retailer_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Retailer_Count) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Dealer_Service_Volume != null && dataSum[0].Dealer_Service_Volume != 0){
            htmlString +='<tr><td class=" auto">Dealer Service Volume %</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+ convertValueInPersent(dataDistrictSum[ds].Dealer_Service_Volume) + '%</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+ convertValueInPersent(dataDistrySum[dd].Dealer_Service_Volume) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Service_Volume) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Dealer_Service_Volume) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Service_Volume) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }


                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Dealer_Service_Volume) + ' %</td>';
                        currState = data[i].State; 
                        tt++;
                    }
                 }

                let exactValue = convertValueInPersent(data[i].Dealer_Service_Volume); 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+ exactValue + '%</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+ convertValueInPersent(dataDistrictSum[ds].Dealer_Service_Volume) + '%</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+ convertValueInPersent(dataDistrySum[dd].Dealer_Service_Volume) + '%</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+ convertValueInPersent(dataTerrySum[tt].Dealer_Service_Volume) + '%</td>';
                    }
                }
            }
            htmlString +='<td> '+ convertValueInPersent(dataSum[0].Dealer_Service_Volume) + '%</td></tr>';
    }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].SKU_Distributors != null && dataSum[0].SKU_Distributors != 0){
            htmlString +='<tr><td class=" auto"># SKU Billed To Distributor</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
                
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Distributors) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Distributors) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Distributors) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Distributors) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Distributors) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Distributors) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].SKU_Distributors; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Distributors) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Distributors) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Distributors) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].SKU_Distributors) + '</td></tr>';
         }
        
         tt=0;
         dd=0;
         ds=0;
        if(dataSum[0].SKU_Retailers != null && dataSum[0].SKU_Retailers != 0){
            htmlString +='<tr><td class=" auto"># SKU sold To Retailers</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){


                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Retailers) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Retailers) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Retailers) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Retailers) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Retailers) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Retailers) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].SKU_Retailers; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';
                

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Retailers) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Retailers) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Retailers) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].SKU_Retailers)+ '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Paid_Service_Volume != null && dataSum[0].Paid_Service_Volume != 0){
            htmlString +='<tr><td class=" auto">Paid Service Volume</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Paid_Service_volume) + '%</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Paid_Service_volume) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Paid_Service_Volume) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Paid_Service_volume) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Paid_Service_Volume) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Paid_Service_Volume) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                let exactValue = data[i].Paid_Service_Volume;      
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+convertValueInPersent(exactValue) + '%</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Paid_Service_Volume) + '%</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Paid_Service_Volume) + '%</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Paid_Service_Volume) + '%</td>';
                    }
                }
            }
            htmlString +='<td> '+convertValueInPersent(dataSum[0].Paid_Service_Volume) + '%</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Total_Vehicle_Count != null && dataSum[0].Total_Vehicle_Count != 0){
            htmlString +='<tr><td class=" auto"> Vehicle Population</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Total_Vehicle_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Vehicle_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Vehicle_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count)  + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }



                let exactValue = data[i].Total_Vehicle_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Total_Vehicle_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Vehicle_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Total_Vehicle_Count) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Retailer_Lac_Vehicles != null && dataSum[0].Retailer_Lac_Vehicles != 0){
            htmlString +='<tr><td class=" auto">Retailer/ Lac Vehicles</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Retailer_Lac_Vehicles) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Lac_Vehicles) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Lac_Vehicles) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Lac_Vehicles) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Lac_Vehicles) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Lac_Vehicles) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].Retailer_Lac_Vehicles; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Retailer_Lac_Vehicles) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Lac_Vehicles) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Lac_Vehicles) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Retailer_Lac_Vehicles)+ '</td></tr>';  
        }
        htmlString +='</tbody></table>'
    }
    $("#retailerStateLoader").css('display', 'none');
    $("#attributesTableId").css('display', 'block');
    $('#attributesTableId').empty();
    stateGen='';
    //dirllTypeView=''
    secondLevelTotal = false;
    distrubuteLevelTotal = false;
    districtLevelTotal = false;
    data= null
    dataSum= null
    currentPage= null
    dataTerrySum = null
    if (htmlString == '') {
        $('#attributesTableId').append("<tr ><td class='noDataTd' colspan='14'>No Data</td></tr>")
    } else {
        $('#attributesTableId').append(htmlString);
    }
    
}


let lastState="";
function createGeneralDrillDownFilterData(stateGen,currentPage){
    allDistriFilterData=[];
    let yearData = $("#yearFilter").val();
    let monthDataNum=$("#monthFilter").val();
    let stateData=$("#stateFilter").val();
   // let territoryData=$("#territoryFilter").val();

    let categoryData=$("#partCategoryFilter").val();
    var notSelectedPart = $("#partCategoryFilter").find('option').not(':selected');
    var arrayOfUnselectedPart = notSelectedPart.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedPart==0){
        categoryData="";
    }

    let distributorData ='';
    if(idMeta !='' && stateMeta == ''){
        distributorData = idMeta;
   }else{
     distributorData=$("#distributorFilter").val();
    if(distributorData.length > 1){
    var notSelectedDitri = $("#distributorFilter").find('option').not(':selected');
    var arrayOfUnselectedDistri = notSelectedDitri.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedDistri==0){
        distributorData="";
    }
    }
}
    
    let territoryData=$("#territoryFilter").val();
    var notSelectedTerry = $("#territoryFilter").find('option').not(':selected');
    var arrayOfUnselectedTerry = notSelectedTerry.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedTerry==0){
        territoryData="";
    }

    let dateData=$("#dateFilter").val();
    var notSelectedDate = $("#dateFilter").find('option').not(':selected');
    var arrayOfUnselectedDate = notSelectedDate.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedDate==0){
        dateData="";
    }

    if(stateMeta == "")
    stateData = stateData != '' ? stateData : defaultStateSelected;
   else if(stateMeta != "")
   stateData = stateData != '' ? stateData : stateMeta;

    allDistriFilterData.push({ dataType: "String", key: 'Year', value: yearData.toString() });
    allDistriFilterData.push({ dataType: "String", key: 'Month', value: monthDataNum.toString() });
    if(currentPage == "Territory"){
        allDistriFilterData.push({dataType:  "String", key: 'State',value:stateGen.toString()});
    }else if(currentPage == "Distributers"){
        allDistriFilterData.push({dataType:  "String", key: 'State',value:singleStateValue.toString()});
        allDistriFilterData.push({dataType:  "String", key: 'Territory',value:stateGen.toString()});
    }else if(currentPage == "District"){
        allDistriFilterData.push({dataType:  "String", key: 'State',value:singleStateValue.toString()});
        allDistriFilterData.push({dataType:  "String", key: 'Territory',value:singleTerryValue.toString()});
        allDistriFilterData.push({dataType:  "String", key: 'distributorID',value:stateGen.toString()});
    }else{
        allDistriFilterData.push({dataType:  "String", key: 'State',value:stateData.toString()});
    }
    allDistriFilterData.push({ dataType: "String", key: 'PartCategory', value: categoryData.toString() });
    allDistriFilterData.push({dataType:  "String", key: 'Custom_Date',value:dateData.toString()});

    return allDistriFilterData;
}

function createGeneralFilterData(){
    allDistriFilterData=[];
    let yearData = $("#yearFilter").val();
    let monthDataNum=$("#monthFilter").val();
    let stateData=$("#stateFilter").val();
    if(stateData == '')
    pupulatingAllFilter();

    let categoryData=$("#partCategoryFilter").val();
    var notSelectedPart = $("#partCategoryFilter").find('option').not(':selected');
    var arrayOfUnselectedPart = notSelectedPart.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedPart==0){
        categoryData="";
    }

    let distributorData ='';
    if(idMeta !='' && stateMeta == ''){
        distributorData = idMeta;
   }else{
     distributorData=$("#distributorFilter").val();
    if(distributorData.length > 1){
    var notSelectedDitri = $("#distributorFilter").find('option').not(':selected');
    var arrayOfUnselectedDistri = notSelectedDitri.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedDistri==0){
        distributorData="";
    }
    }
}
    let territoryData=$("#territoryFilter").val();
    var notSelectedTerry = $("#territoryFilter").find('option').not(':selected');
    var arrayOfUnselectedTerry = notSelectedTerry.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedTerry==0){
        territoryData="";
    }

    let dateData=$("#dateFilter").val();
    var notSelectedDate = $("#dateFilter").find('option').not(':selected');
    var arrayOfUnselectedDate = notSelectedDate.map(function () {
        return this.value;
    }).get();
    if (arrayOfUnselectedDate==0){
        dateData="";
    }

//     if(stateMeta == "")
//     stateData = stateData != '' ? stateData : defaultStateSelected;
//    else if(stateMeta != "")
//    stateData = stateData != '' ? stateData : stateMeta;
    allDistriFilterData.push({ dataType: "String", key: 'Year', value: yearData.toString() });
    allDistriFilterData.push({ dataType: "String", key: 'Month', value: monthDataNum.toString() });
    allDistriFilterData.push({ dataType: "String", key: 'State', value: stateData.toString() });  
    allDistriFilterData.push({ dataType: "String", key: 'PartCategory', value: categoryData.toString() });
    allDistriFilterData.push({dataType:  "String", key: 'Territory',value:territoryData.toString()});
    allDistriFilterData.push({dataType:  "String", key: 'distributorID',value:distributorData.toString()});
    allDistriFilterData.push({dataType:  "String", key: 'Custom_Date',value:dateData.toString()});
    
    return allDistriFilterData;
}

// function createCommentDataCalling(){
//     let report = "Bench - Marking";
//     let title = $(".reportTitle").text();
//     let filterData = createGeneralFilterData();
//     let command={};
// 	command.displayName = "Table View";
//     command.reportDisplayName = title;
//     command.filterData=filterData
//     commentDataApiObject={report:report,command:command,title:title}

//         trackCustomEvent('Comment Submitted', {
//             "companyId": companyId.toString(),
//             "userId": userId.toString(),
//             "dashboardId": dashboardId.toString(),
//             "reportName": title.toString()
//         });
//         $('#commentModal').modal('show');
// }

function sharedDataCalling() {
    //mahesh
    let report = "Bench_Marcking";
    let title = $(".reportTitle").text();
    let filterData = createGeneralFilterData();
    let command={};
    command.displayName = "Table View";
    command.reportDisplayName = title;
    command.filterData=filterData
    let sharedData;

    var table = document.getElementById("sharedDataId"); 

    let headers = "Attributes,"
    $("#sharedDataId tr").each(function(){
        let headerValue = $(this).find("td:first").text();
        if(headerValue != "")
        headers += headerValue+","; 
    });
    if(drillStatus == "terryLevel"){
        var totalCol = document.getElementById("sharedDataId").rows[2].cells.length; //total columns
       
        sharedData = headers+"\n"; 
        for(let j=1; j<totalCol-1;j++){
            for(let i=1; i<table.rows.length; i++){
                 sharedData += (table.rows[i].cells[j].innerHTML).replace("</a>", "").replace(/<.*>/, '')+",";
            }
            sharedData +="\n";
        }
        shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData};
        trackCustomEvent('Share Data Pop up Open', {
                        "companyId": companyId.toString(),
                        "userId": userId.toString(),
                        "dashboardId": dashboardId.toString(),
                        "reportName": reportTitle.toString()
            });
        $('#myModal').modal('show');

    }else if (drillStatus == "distryLevel"){
        
        let title = $(".reportTitle").text();
        let shareDistReqObj;
        if(singleSection){

             totalCol = document.getElementById("sharedDataId").rows[3].cells.length;
            table = document.getElementById('sharedDataId');
            sharedData = headers+"\n";
            for(let j=1; j<totalCol;j++){
                for(let i=2; i<table.rows.length; i++){
                    sharedData += (table.rows[i].cells[j].innerHTML).replace("</a>", "").replace(/<.*>/, '')+",";
                }
                sharedData +="\n";
            }
            shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData};
            trackCustomEvent('Share Data Pop up Open', {
                            "companyId": companyId.toString(),
                            "userId": userId.toString(),
                            "dashboardId": dashboardId.toString(),
                            "reportName": reportTitle.toString()
                });
            $('#myModal').modal('show');


        }else{
        if(title == "General"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createGeneralFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "General_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData = "Attributes,Satate,Territorry,Addressability,Market Share %,Sales,# Retailers,Retailer/ Lac Vehicles,# SKU Billed To Distributor,Vehicle Population,Paid Service Volume,# SKU sold To Retailers,# Distributors,Dealer Service Volume %,# Dealers,Dealer Contribution To Sales \n"; 
                    for(let i=0; i<data.length;i++){
                        sharedData +=data[i].Distributor+","+data[i].State+","+data[i].Distributor_Territory+","+numberFormatter(data[i].Potential)+","+convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Primary_Sales)+","+numberFormatter(data[i].Retailer_Count)+","+numberFormatter(data[i].Retailer_Lac_Vehicles)+","+numberFormatter(data[i].SKU_Distributors)+","+numberFormatter(data[i].Total_Vehicle_Count)+","+convertValueInPersent(data[i].Paid_Service_Volume)+"%,"+numberFormatter(data[i].SKU_Retailers)+","+numberFormatter(data[i].Distributor_Count)+","+convertValueInPersent(data[i].Dealer_Service_Volume)+"%,"+numberFormatter(data[i].Dealer_Count)+","+convertValueInPersent(data[i].Dealer_Contribution)+"%\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData};
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });



        }else if(title == "Retailer"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createTerryFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "Retailer_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData = "Attributes,State,Territory,Addressability,Sales,Market Share %,# Distributors,# Dealers,Dealer Contribution To Sales(Primary),# Retailers,Average Invoice Value,# Unique SKUs sold to Retailers,Avg Parts Per Invoice, # Large & V Large Retailers,# Medium Retailers,Small & V Small Retailers,Sales Value % Large & V Large Reatailers,Sales Value % Medium Reatailers,Sales Value % Small & V Small Reatailers,Invoice Frequency/Retailer \n"; 
                    for(let i=0; i<data.length;i++){
                        sharedData +=data[i].Distributor+","+data[i].State+","+data[i].Distributor_Territory+","+numberFormatter(data[i].Potential)+","+numberFormatter(data[i].Penetration)+"%,"+numberFormatter(data[i].Primary_Sales)+","
                        +convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Distributor_Count)+","+numberFormatter(data[i].Dealer_Count)+","+numberFormatter(data[i].Dealer_Contribution)+","
                        +convertValueInPersent(data[i].Retailer_Count)+"%,"+numberFormatter(data[i].Invoice_Sales)+","+numberFormatter(data[i].SKU_Count)+","+convertValueInPersent(data[i].Avg_Part_Per_Invoice)+"%,"+numberFormatter(data[i].Large_Count)+","+numberFormatter(data[i].Medium_Count)+","+numberFormatter(data[i].Small_Count)+","+convertValueInPersent(data[i].Large_Sales)+"%,"+convertValueInPersent(data[i].Medium_Sales)+"%,"+convertValueInPersent(data[i].Small_Sales)+"%,"+numberFormatter(data[i].Invoice_Per_Retailer)+"\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });

        }else if(title == "Part Reach"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createGeneralFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "Part_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData ="Attributes,State,Territory,Addressability,Sales,Market Share %,# Distributors,# Retailers,# Unique SKUs sold,Avg.Parts per invoice,Number / Value of parts with MRP less than Rs. 100, Number / Value of parts with MRP from Rs. 101 - 500,Number / Value of parts with MRP from Rs. 501 & more\n"
                    for(let i=0; i<data.length;i++){
                        sharedData +=data[i].Distributor+","+data[i].State+","+data[i].Distributor_Territory+","+numberFormatter(data[i].Potential)+","+numberFormatter(data[i].Primary_Sales)+"%,"+convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Distributor_Count)+","+numberFormatter(data[i].Retailer_Count)+","+numberFormatter(data[i].sku_Lt_100)+","
                        +numberFormatter(data[i].sku_bw_101_500)+","+numberFormatter(data[i].sku_gt_500)+","+numberFormatter(data[i].SKU_Count)+","+numberFormatter(data[i].Avg_Part_Per_Invoice)+","+
                        +numberFormatter(dataDistrictSum[ds].RT_lt_100) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_lt_100) + ","+numberFormatter(dataDistrictSum[ds].RT_101_500) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_101_500)+","+numberFormatter(dataDistrictSum[ds].RT_gt_500)  +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_gt_500) + "\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });
        }else if(title == "Service Level"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createGeneralFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "Service_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData = "Attributes,State,Territory,Addressability,Sales,Market Share %,# Distributors,# Dealers,Dealer Contribution To Sales(Primary),# Total Service Volume,# SKU bought by Service Center,Paid service,Service volume / Total vehicle population,Total vehicle population \n";
                     for(let i=0; i<data.length;i++){
                        sharedData +=data[i].Distributor+","+data[i].State+","+data[i].Distributor_Territory+","+numberFormatter(data[i].Potential)+","+convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Primary_Sales)+","+numberFormatter(data[i].Distributor_Count)+","+numberFormatter(data[i].Dealer_Count)+","+numberFormatter(data[i].Dealer_Sales)+","+numberFormatter(data[i].Total_Service_Volume)+","+numberFormatter(data[i].SKU_Count)+","+numberFormatter(data[i].Paid_Service_per)+","+numberFormatter(data[i].Service_Per_BikePopulation)+","+numberFormatter(data[i].Total_Vehicle_Count)+"\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });
        }else{
            sharedData +="\n";
        }
    }
    }else if (drillStatus == "districtLevel"){
        let title = $(".reportTitle").text();
        let shareDistReqObj;
        if(singleSection){
            var totalCol = document.getElementById("sharedDataId").rows[4].cells.length;
            var table = document.getElementById('sharedDataId');
            sharedData = headers+"\n";
            for(let j=1; j<totalCol;j++){
                for(let i=3; i<table.rows.length; i++){
                    sharedData += (table.rows[i].cells[j].innerHTML).replace("</a>", "").replace(/<.*>/, '')+",";
                }
                sharedData +="\n";
            }
            shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
            trackCustomEvent('Share Data Pop up Open', {
                            "companyId": companyId.toString(),
                            "userId": userId.toString(),
                            "dashboardId": dashboardId.toString(),
                            "reportName": reportTitle.toString()
                });
            $('#myModal').modal('show');
        }else{
        if(title == "General"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createGeneralFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "General_View_District_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData = "Attributes,Satate,Territorry,Distributor,Addressability,Market Share %,Sales,# Retailers,Retailer/ Lac Vehicles,# SKU Billed To Distributor,Vehicle Population,Paid Service Volume,# SKU sold To Retailers,# Distributors,Dealer Service Volume %,# Dealers,Dealer Contribution To Sales \n"; 
                    for(let i=0; i<data.length;i++){
                        sharedData +=data[i].DistrictName+","+data[i].State+","+data[i].Distributor_Territory+","+data[i].Distributor+","+numberFormatter(data[i].Potential)+","+convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Primary_Sales)+","+numberFormatter(data[i].Retailer_Count)+","+numberFormatter(data[i].Retailer_Lac_Vehicles)+","+numberFormatter(data[i].SKU_Distributors)+","+numberFormatter(data[i].Total_Vehicle_Count)+","+convertValueInPersent(data[i].Paid_Service_Volume)+"%,"+numberFormatter(data[i].SKU_Retailers)+","+numberFormatter(data[i].Distributor_Count)+","+convertValueInPersent(data[i].Dealer_Service_Volume)+"%,"+numberFormatter(data[i].Dealer_Count)+","+convertValueInPersent(data[i].Dealer_Contribution)+"%\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });
        }else if(title == "Retailer"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createTerryFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "Retailer_View_District_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData = "Attributes,State,Territory,Distributor,Addressability,Sales,Market Share %,# Distributors,# Dealers,Dealer Contribution To Sales(Primary),# Retailers,Average Invoice Value,# Unique SKUs sold to Retailers,Avg Parts Per Invoice, # Large & V Large Retailers,# Medium Retailers,Small & V Small Retailers,Sales Value % Large & V Large Reatailers,Sales Value % Medium Reatailers,Sales Value % Small & V Small Reatailers,Invoice Frequency/Retailer \n"; 
                    for(let i=0; i<data.length;i++){
                        sharedData +=data[i].DistrictName+","+data[i].State+","+data[i].Distributor_Territory+","+data[i].Distributor+","+numberFormatter(data[i].Potential)+","+numberFormatter(data[i].Penetration)+"%,"+numberFormatter(data[i].Primary_Sales)+","
                        +convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Distributor_Count)+","+numberFormatter(data[i].Dealer_Count)+","+numberFormatter(data[i].Dealer_Contribution)+","
                        +convertValueInPersent(data[i].Retailer_Count)+"%,"+numberFormatter(data[i].Invoice_Sales)+","+numberFormatter(data[i].SKU_Count)+","+convertValueInPersent(data[i].Avg_Part_Per_Invoice)+"%,"+numberFormatter(data[i].Large_Count)+","+numberFormatter(data[i].Medium_Count)+","+numberFormatter(data[i].Small_Count)+","+convertValueInPersent(data[i].Large_Sales)+"%,"+convertValueInPersent(data[i].Medium_Sales)+"%,"+convertValueInPersent(data[i].Small_Sales)+"%,"+numberFormatter(data[i].Invoice_Per_Retailer)+"\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });
        }else if(title == "Part Reach"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createGeneralFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "Part_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData ="Attributes,State,Territory,Distributor,Addressability,Sales,Market Share %,# Distributors,# Retailers,# Unique SKUs sold,Avg.Parts per invoice,# Unique items bought by Service Center,Number / Value of parts with MRP less than Rs. 100, Number / Value of parts with MRP from Rs. 101 - 500,Number / Value of parts with MRP from Rs. 501 & more\n"
                    for(let i=0; i<data.length;i++){
                        sharedData +=data[i].DistrictName+","+data[i].State+","+data[i].Distributor_Territory+","+data[i].Distributor+","+numberFormatter(data[i].Potential)+","+numberFormatter(data[i].Primary_Sales)+"%,"+convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Distributor_Count)+","+numberFormatter(data[i].Retailer_Count)+","+numberFormatter(data[i].sku_Lt_100)+","
                        +numberFormatter(data[i].sku_bw_101_500)+","+numberFormatter(data[i].sku_gt_500)+","+numberFormatter(data[i].SKU_Count)+","+numberFormatter(data[i].Avg_Part_Per_Invoice)+","+numberFormatter(data[i].SKU_Count_Bajaj)+","+
                        +numberFormatter(dataDistrictSum[ds].RT_lt_100) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_lt_100) + ","+numberFormatter(dataDistrictSum[ds].RT_101_500) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_101_500)+","+numberFormatter(dataDistrictSum[ds].RT_gt_500)  +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_gt_500) + "\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });
        }else if(title == "Service Level"){
            $('#myShareModal').modal('show');
            if (shareDistReqObj) {
                shareDistReqObj.abort();
                shareDistReqObj = null;
            }
            let terryFilterData =  createGeneralFilterData();
            shareDistReqObj = $.ajax({
                url: getApiDomain(),
                type: 'POST',
                data: JSON.stringify({ 'filter': "Service_View_District_Table_V2", 'chartDataForms': terryFilterData }),
                success: (function (resultData) {
                    $('#myShareModal').modal('hide');
                    let data = resultData.data.data[0];
                    sharedData = "Attributes,State,Territory,Distributor,Addressability,Sales,Market Share %,# Distributors,# Dealers,Dealer Contribution To Sales(Primary),# Total Service Volume,# SKU bought by Service Centers,Paid service,Service volume / Total vehicle population,Total vehicle Population \n";
                     for(let i=0; i<data.length;i++){
                        sharedData +=data[i].DistrictName+","+data[i].State+","+data[i].Distributor_Territory+","+data[i].Distributor+","+numberFormatter(data[i].Potential)+","+convertValueInPersent(data[i].Penetration)+"%,"+numberFormatter(data[i].Primary_Sales)+","+numberFormatter(data[i].Distributor_Count)+","+numberFormatter(data[i].Dealer_Count)+","+numberFormatter(data[i].Dealer_Sales)+","+numberFormatter(data[i].Total_Service_Volume)+","+numberFormatter(data[i].SKU_Count)+","+numberFormatter(data[i].Paid_Service_per)+","+numberFormatter(data[i].Service_Per_BikePopulation)+","+numberFormatter(data[i].Total_Vehicle_Count)+"\n";
                    }
                    shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
                    trackCustomEvent('Share Data Pop up Open', {
                                    "companyId": companyId.toString(),
                                    "userId": userId.toString(),
                                    "dashboardId": dashboardId.toString(),
                                    "reportName": reportTitle.toString()
                        });
                    $('#myModal').modal('show');
                    shareDistReqObj = null;
                    data = null;
                }),
                error: (function (err) {
                    shareDistReqObj = null;
                    console.log(err);
                })
            });
        }else{
            sharedData +="\n";
        }
    }

    }else{
        let totalColumns = $("#sharedDataId tr th").length;
        var table = document.getElementById('sharedDataId');
        sharedData = headers+"\n";
        for(let j=1; j<totalColumns;j++){
            for(let i=0; i<table.rows.length; i++){
                 sharedData += (table.rows[i].cells[j].innerHTML).replace("</a>", "").replace(/<.*>/, '')+",";
            }
            sharedData +="\n";
        }
        shareDataApiObject = {report:report,command:command,title:title,sharedData:sharedData}
        trackCustomEvent('Share Data Pop up Open', {
                        "companyId": companyId.toString(),
                        "userId": userId.toString(),
                        "dashboardId": dashboardId.toString(),
                        "reportName": reportTitle.toString()
            });
        $('#myModal').modal('show');

}
}   