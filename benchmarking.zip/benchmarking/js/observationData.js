
 function ClickObservtionCommentTORedirectToPage(exactViewTemp,dirllTypeViewTemp){
        let currenntView = $('.reportTitle').text();
        exactView = exactViewTemp;
        dirllTypeView = dirllTypeViewTemp;
        if (currenntView == 'General') {
        $("#retailContent").show();
        $("#retailerStateLoader").css('display', 'block');
        $("#attributesTableId").css('display', 'none');
        $(".zui-sticky-col").css('width', '26.6%')
        if (exactView == "stateView") {
            stateGeneralDataFromApi();
        } else if (exactView == "territoryView") {
            if (dirllTypeView == "SecondLevel") {
                stateGen = dirllTypeView;
                generalterriDrillDataFromApi(stateGen);
            } else {
                generalterriDrillDataFromApi();
            }
        } else if (exactView == "distributerView") {
            if (dirllTypeView == "SecondLevel") {
                stateGen = dirllTypeView;
                generalDistyDrillDataFromApi(stateGen);
            } else {
                generalDistyDrillDataFromApi();
            }
        } else if (exactView == "districtView") {
            if (dirllTypeView == "SecondLevel") {
                stateGen = dirllTypeView;
                generalDistictDrillDataFromApi(stateGen);
            } else {
                generalDistictDrillDataFromApi();
            }
        } else {
            stateGeneralDataFromApi();
        }
    } else if (currenntView == 'Retailer') {
        $(".zui-sticky-col").css('width', '26.6%')
        $("#retailContent").show();
        $("#retailerStateLoader").css('display', 'block');
        $("#attributesTableId").css('display', 'none');
        if (exactView == "stateView") {
            retaiStateDataFromApi();
        } else if (exactView == "territoryView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                retailerTerryDrillDataFromApi(state);
            } else {
                retailerTerryDrillDataFromApi();
            }
        } else if (exactView == "distributerView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                retailerDistryDrillDataFromApi(state);
            } else {
                retailerDistryDrillDataFromApi();
            }
        } else if (exactView == "districtView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                retailerDistictDrillDataFromApi(state);
            } else {
                retailerDistictDrillDataFromApi();
            }
        } else {
            retaiStateDataFromApi();
        }
    } else if (currenntView == 'Part Reach') {
        $(".zui-sticky-col").css('width', '26.6%')
        $("#generalContent").hide();
        $("#retailContent").show();
        $("#partContent").hide();
        $("#serviceContent").hide();
        $("#retailerStateLoader").css('display', 'block');
        $("#attributesTableId").css('display', 'none');
        if (exactView == "stateView") {
            partStateDataFromApi();
        } else if (exactView == "territoryView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                partTerryDrillDown(state);
            } else {
                partTerryDrillDown();
            }
        } else if (exactView == "distributerView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                partDitributDrillDown(state);
            } else {
                partDitributDrillDown();
            }
        } else if (exactView == "districtView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                partDistictDrillDataFromApi(state);
            } else {
                partDistictDrillDataFromApi();
            }
        } else {
            partStateDataFromApi();
        }
       
    }else if (currenntView == 'Service Level') {
        $(".zui-sticky-col").css('width', '26.6%')
        $("#generalContent").hide();
        $("#retailContent").show();
        $("#partContent").hide();
        $("#serviceContent").hide();
        $("#retailerStateLoader").css('display', 'block');
        $("#attributesTableId").css('display', 'none');
        if (exactView == "stateView") {
            serviceStateDataFromApi();
        } else if (exactView == "territoryView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                serviceTerryDrillDown(state);
            } else {
                serviceTerryDrillDown();
            }
        } else if (exactView == "distributerView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                serviceDitributDrillDown(state);
            } else {
                serviceDitributDrillDown();
            }
        } else if (exactView == "districtView") {
            if (dirllTypeView == "SecondLevel") {
                state = dirllTypeView;
                serviceDistrictDrillDown(state);
            } else {
                serviceDistrictDrillDown();
            }
        } else {
            serviceStateDataFromApi();
        }
    }
    }


    function setFiltersForData(filterData,viewName,drillDownLevel) {
        if (!filterData) {
            return;
        }
        let filterDatakeys = Object.keys(filterData);
        let filterName;
        let valArr;
        let currentEle;
      preSelectedFilterArray = [];
        for (let i = 0; i < filterDatakeys.length; i++) {
            filterName = filterDatakeys[i];
            valArr = filterData[filterDatakeys[i]].split(",");
            currentEle = $('.filter[id="' + filterName + '"]');
            if (!currentEle) {
                break;
            }
           
            if (currentEle.prop('multiple')) {
                currentEle.multiselect('destroy');
                currentEle.val(valArr);
                currentEle.multiselect({
                    allSelectedText: 'All',
                    numberDisplayed: 1,
                    nonSelectedText: 'All',
                    includeSelectAllOption: true,
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true
                });
    
            } else {
                currentEle.val(valArr);
            }
// if(filterName == "Month" || filterName == "Year"){
//     currentEle.trigger('change');
// }

            preSelectedFilterArray.push({ filterName: filterName, filterValue: valArr });
            if(i == filterDatakeys.length -1){
                
                $('.reportTitle').text(viewName);
               // let pageId = getPageIdBaseOnViewName(viewName);
              drillDownLevel =   JSON.parse(drillDownLevel);
              ClickObservtionCommentTORedirectToPage(drillDownLevel.exactView,drillDownLevel.dirllTypeView);
            
            }
            if(filterName == "PartCode" && valArr != "")
            partCodeFullScope1 = valArr;
            if(filterName == "RetailerID" && valArr != "")
            partCodeFullScope = valArr;
           
        }              
    
    }        
    // function getPageIdBaseOnViewName(viewName) {
    //     let pageId = '';
    //     switch (viewName) {
    //         case "General":
    //             pageId = "generalView";
    //             break;
    //         case "Retailer":
    //             pageId = "retailerView";
    //             break;
    //         case "Part Reach":
    //             pageId = "partView";
    //             break;
    //         case "Service Level":
    //             pageId = "serviceView";
    //             break;               
    //     }
    
    //     return pageId;
    // }
    
    var global_initialFilterData;
function resetAllFilters() {
    setFiltersForData(global_initialFilterData);

}


function getDillDownDetails(exactView,dirllTypeView){
    let dirlldownObj = {};
    dirlldownObj['exactView'] =  exactView.toString();
    dirlldownObj['dirllTypeView'] =  dirllTypeView.toString();
return dirlldownObj;
}

function getAllFiltersData() {
    let filterDataObj = {};
    let yearData = $("#yearFilter").val();
    let monthDataNum = $("#monthFilter").val();
    filterDataObj['yearFilter'] =  yearData.toString();
    filterDataObj['monthFilter'] =  monthDataNum.toString();
for(let i=0; i < preSelectedFilterArray.length; i++){
    filterDataObj[preSelectedFilterArray[i].filterName] = (preSelectedFilterArray[i].filterValue).toString();
} 
filterDataObj["stateMeta"] = stateMeta.toString();
filterDataObj["idMeta"] = idMeta.toString();

return filterDataObj;

}

function filterReportEvent(event){
    let filter =event.target.attributes.data["value"];
    let filterValueArray = JSON.parse(filter);
    let pageViewName = event.target.attributes.about["value"];
    let drillDownLevel = event.target.attributes.level["value"];
    setFiltersForData(filterValueArray,pageViewName,drillDownLevel);
}

function createCommentDataCalling() {
    let report = "Bench - Marking";
    let title = $(".reportTitle").text();
    let filterData = getAllFiltersData();
    let command = {};
    command.displayName = "Table View";
    command.reportDisplayName = title;
    command.filterData = filterData;
    commentDataApiObject = { report: report, command: command, title: title }

    trackCustomEvent('Comment Submitted', {
        "companyId": companyId.toString(),
        "userId": userId.toString(),
        "dashboardId": dashboardId.toString(),
        "reportName": title.toString()
    });
    $('#commentModal').modal('show');
}


