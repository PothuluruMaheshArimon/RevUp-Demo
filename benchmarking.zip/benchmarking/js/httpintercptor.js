

$.ajaxSetup({
    beforeSend: function (xhr) {
   //  xhr.setRequestHeader('Authorization', 'Bearer-eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJrb3Jhc2VseS04Mzk0QHlvcG1haWwuY29tIiwianRpIjoiMzYxIiwiYXV0aCI6IlJPTEVfQ09ORklHVVJFUiIsImNvbXBhbnlJZCI6IjExMCIsInNlc3Npb25JZCI6IjgwOWNmZTljNmY2OTQzMTNiMWQ2ZmNmZjA1OTZjZTI2IiwiZXhwIjoxNjI5MzQ4MDAwfQ.TrIspVebYFjKLTyU6hj1zSanuC0QyuOtUQrly_DD9w-mXOTg88OVunuizhvNrojuVToJfXW0wtKguQvw1OW88A');
    xhr.setRequestHeader('Content-type', 'application/json');
    }
});