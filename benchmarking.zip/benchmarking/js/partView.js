 exactView ='';
 dirllTypeView='';
let partViewValue='';
let partStateObj;
function partStateDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (partStateObj) {
        partStateObj.abort();
        partStateObj = null;
    }
    let currentPage = "State";
    exactView = "stateView";
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_State_Table_V2";
    partStateObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_State_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            partTotalDataApi(data,currentPage,state);
            partStateObj = null;
            data = null;
        }),
        error: (function (err) {
            partStateObj = null;
            console.log(err);
        })
    });
}

let partTerryObj;
function partTerryDrillDown(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (partTerryObj) {
        partTerryObj.abort();
        partTerryObj = null;
    }
    let currentPage = "Territory";
    exactView = "territoryView";
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_Territory_Table_V2";
    partTerryObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_Territory_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            partTotalDataApi(data,currentPage,state);
            partTerryObj = null;
            data = null;
        }),
        error: (function (err) {
            partTerryObj = null;
            console.log(err);
        })
    });
}

let partDistryObj;
function partDitributDrillDown(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (partDistryObj) {
        partDistryObj.abort();
        partDistryObj = null;
    }
    let currentPage = "Distributers";
    exactView = "distributerView";
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_Distributor_Table_V2";
    partDistryObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            partTotalDataApi(data,currentPage,state);
            partDistryObj = null;
            data = null;
        }),
        error: (function (err) {
            partDistryObj = null;
            console.log(err);
        })
    });
}



let districtPartReqObj;
function partDistictDrillDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "District";
    exactView = "districtView";
    if(state == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (districtDrillReqObj) {
            districtDrillReqObj.abort();
            districtDrillReqObj = null;
        }
        let terryFilterData;
        if(state != undefined && state != "" && state != "SecondLevel"){
            terryFilterData =  createDrillDownFilterData(state,currentPage);
        }else{
            terryFilterData = createTerryFilterData();
        }
        let procedureName = "Part_View_District_Table_V2";
        districtPartReqObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "Part_View_District_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                partTotalDataApi(data,currentPage,state)
                districtPartReqObj = null;
                data = null;
            }),
            error: (function (err) {
                districtPartReqObj = null;
                console.log(err);
            })
        });

}


let partTotalObj;
function partTotalDataApi(data,currentPage,state){
    if (partTotalObj) {
        partTotalObj.abort();
        partTotalObj = null;
    }
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_State_Total_V2";
    partTotalObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_State_Total_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataSum = resultData.data.data[0];
            if(state == "SecondLevel" && currentPage == "Territory"){
                territoryPartTotalFetching(data,dataSum,currentPage,state);
            }else if(state == "SecondLevel" && currentPage == "Distributers"){
                territoryPartTotalFetching(data,dataSum,currentPage,state);
            }else if(state == "SecondLevel" && currentPage == "District"){
                territoryPartTotalFetching(data,dataSum,currentPage,state);
            }else{
                partDataToInsertTable(data,dataSum,currentPage,state);
            }
            partTotalObj = null;
            data = null;
        }),
        error: (function (err) {
            partTotalObj = null;
            console.log(err);
        })
    });
}

let retTerryPartObj;
function territoryPartTotalFetching(data,dataSum,currentPage,state){
    if (retTerryPartObj) {
        retTerryPartObj.abort();
        retTerryPartObj = null;
    }
    let terryFilterData;
    if(state != undefined && state != "" && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage);
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_State_Table_V2";
    retTerryPartObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_State_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataTerrySum = resultData.data.data[0];
            if(state == "SecondLevel" && currentPage == "Distributers"){
                distributerPartTotalFetching(data,dataSum,currentPage,state,dataTerrySum);
            }else if(state == "SecondLevel" && currentPage == "District"){
                distributerPartTotalFetching(data,dataSum,currentPage,state,dataTerrySum);
            }else{
                partDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum);
            }
            retTerryPartObj = null;
            data = null;
        }),
        error: (function (err) {
            retTerryPartObj = null;
            console.log(err);
        })
    });

}

let distyPartTotaObj;
function distributerPartTotalFetching(data,dataSum,currentPage,state,dataTerrySum){
    if (distyPartTotaObj) {
        distyPartTotaObj.abort();
        distyPartTotaObj = null;
    }
    let terryFilterData;
    if(state != undefined && state != "" && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage);
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_Territory_Table_V2";
    distyPartTotaObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_Territory_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataDistrySum = resultData.data.data[0];
            if(state == "SecondLevel" && currentPage == "District"){
                partDistrictTotalFetching(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum);
            }else {
                partDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum);
            }
            distyPartTotaObj = null;
            data = null;
        }),
        error: (function (err) {
            distyPartTotaObj = null;
            console.log(err);
        })
    });
}


let distritPartObjTotal;
function partDistrictTotalFetching(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum){
    if (distritPartObjTotal) {
        distritPartObjTotal.abort();
        distritPartObjTotal = null;
    }
    let terryFilterData;
    if(state != undefined && state != "" && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage);
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Part_View_Distributor_Table_V2";
    distritPartObjTotal = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Part_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataDistrictSum = resultData.data.data[0];
            partDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum,dataDistrictSum);
            distritPartObjTotal = null;
            data = null;
        }),
        error: (function (err) {
            distritPartObjTotal = null;
            console.log(err);
        })
    });
}

let distryPartOnlyObj;
function partDistyOnlyDrillDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
        if (distryPartOnlyObj) {
            distryPartOnlyObj.abort();
            distryPartOnlyObj = null;
        }
        let currentPage = "Distributers";
        exactView = "distributerView";
        if(state == "SecondLevel"){
            dirllTypeView = "SecondLevel";
        }else{
            dirllTypeView='';
        }
        let terryFilterData;
        if(state != undefined && state != "" && state != "SecondLevel"){
            terryFilterData =  createDrillDownFilterData(state,currentPage);
        }else{
            terryFilterData = createTerryFilterData();
        }
        let procedureName = "Part_View_Distributor_Only_Table_V2";
        distryPartOnlyObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "Part_View_Distributor_Only_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                partTotalDataApi(data,currentPage,state)
                distryPartOnlyObj = null;
                data = null;
            }),
            error: (function (err) {
                distryPartOnlyObj = null;
                console.log(err);
            })
        });
}


let partDistictOnlyObj;
function partDistictOnlyDrillDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "District";
    exactView = "districtView";
    if(state == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (partDistictOnlyObj) {
            partDistictOnlyObj.abort();
            partDistictOnlyObj = null;
        }
        let terryFilterData;
        if(state != undefined && state != "" && state != "SecondLevel"){
            terryFilterData =  createDrillDownFilterData(state,currentPage);
        }else{
            terryFilterData = createTerryFilterData();
        }
        let procedureName = "Part_View_District_Only_Table_V2";
        partDistictOnlyObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "Part_View_District_Only_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                partTotalDataApi(data,currentPage,state)
                partDistictOnlyObj = null;
                data = null;
            }),
            error: (function (err) {
                partDistictOnlyObj = null;
                console.log(err);
            })
        });
}


function partDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum,dataDistrictSum){
    let htmlString = '';
    if(data.length != 0){
        if(state != "" && state != undefined){
            if(state == "SecondLevel"){
                secondLevelTotal = true;
                if(currentPage == "Territory"){
                    drillStatus='terryLevel'
                    singleSection = false
                    let currState = data[0].State;
                    let stateValue = data[0].State;
                  
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="    text-align: center;" class=" auto">State</th>';
                   for(let i=0; i < data.length; i++){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th   >  </th>';
                        currState = data[i].State;
                        stateValue = data[i].State
                    }

                    if(stateValue != ""){
                        htmlString +='<th style="border-right: aliceblue; text-align: center;">'+stateValue+'</th>'; 
                    }else{
                        htmlString +='<th   ></th>'
                    }
                    stateValue = "";
                        if(i == data.length-1){
                            htmlString += '<th   >  </th>';
                          }
                    }

                    htmlString +='<th rowspan="2" style="cursor:none;">TOTAL</th></tr><tr> <th style="text-align: center;     " class=" auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="partStateDataFromApi()"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="partDitributDrillDown(\'' + serSecDrill + '\')"></i></th>';
                    currState = data[0].State;
                    for(let i=0; i < data.length; i++){
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                            htmlString += '<th> TOTAL </th>';
                            currState = data[i].State;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor_Territory + '</a></th>';
                          if(i == data.length-1){
                            htmlString += '<th> TOTAL </th>';
                          }
                    }
                    
                }
				else if(currentPage == "Distributers"){
                    drillStatus = "distryLevel";
                    singleSection = false
                    let currState = data[0].State;
                    let currterr = data[0].State+data[0].Distributor_Territory;
                    distrubuteLevelTotal = true;
                    let stateValue = data[0].State;
                   
                    
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" >';
                    htmlString += '<thead>';
                    htmlString += '<tr>';
                    htmlString += '<th style=" border-right: aliceblue;text-align: center;" class=" auto">State</th>';
                   for(let i=0; i < data.length; i++){
                    if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                         htmlString += '<th style="    border: none;    ">  </th>';                      
                        currterr = data[i].State+data[i].Distributor_Territory;
                    }
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th style="    border: none;    ">  </th>';      
                        currState = data[i].State;
                        stateValue = data[i].State;
                   }
                   if(stateValue != ""){
                        htmlString +='<th  style="border-right: hidden;" text-align: center;">'+currState+'</th>'; 
                   }else{
                    htmlString +='<th style="    border: none;   "></th>'; 
                   }  
                   stateValue ="";
                        if(i == data.length-1){                          
                            htmlString += '<th style="    border: none;   ">  </th>';
                         }
                    }

                    htmlString += '<th style="    border: none;   ">  </th>';
                    htmlString +='<th rowspan="4" style="cursor:none;">TOTAL </th>';
                    htmlString +='</tr>';
                    htmlString +='<tr>';
                    htmlString +='<th style="text-align: center;  " class=" auto">Territory</th>'
                    
                    currState = data[0].State;
                    currterr = data[0].State+data[0].Distributor_Territory;
                    let distriValue = data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                        
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                            distriValue = data[i].Distributor_Territory;
                        }
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                             htmlString += '<th rowspan="3"> TOTAL </th>';
                            currState = data[i].State;
                        }
                            if(distriValue != ""){
                                htmlString += '<th style="border-right: hidden;""> <a>'+data[i].Distributor_Territory + '</a></th>';
                            }else{
                                htmlString += '<th style="    border: none;"></th>'
                            }
                          distriValue = "";
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none; ">  </th>'; 
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                          
                          }
                    }
                    htmlString +='<tr> <th style="text-align: center;     " class=" auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Up" id="partTerryDownId" onClick="partTerryDrillDown(\'' + serSecDrill + '\')"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="partDistictDrillDataFromApi(\'' + serSecDrill + '\')"></i></th>';
                    currterr = data[0].State+data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                       
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                            
                            currterr = data[i].State+data[i].Distributor_Territory;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th rowspan="3"> TOTAL </th>';                           
                          }
                       
                    }

                }
                else if(currentPage == "District"){
                    drillStatus = "districtLevel"
                    singleSection = false

                    let currState = data[0].State;
                    let currterr = data[0].State+data[0].Distributor_Territory;
                    distrubuteLevelTotal = true;
                    districtLevelTotal = true;
                    let stateValue = data[0].State;
                    let currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                   
                    
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" >';
                    htmlString += '<thead>';
                    htmlString += '<tr>';
                    htmlString += '<th style=" border-right: aliceblue;text-align: center;" class=" auto">State</th>';
                   for(let i=0; i < data.length; i++){

                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<th style="    border: none;    ">  </th>';                      
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                   }

                    if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                         htmlString += '<th style="    border: none;    ">  </th>';                      
                        currterr = data[i].State+data[i].Distributor_Territory;
                    }
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th style="    border: none;    ">  </th>';      
                        currState = data[i].State;
                        stateValue = data[i].State;
                   }
                   if(stateValue != ""){
                        htmlString +='<th  style="border-right: hidden;" text-align: center;">'+currState+'</th>'; 
                   }else{
                    htmlString +='<th style="    border: none;   "></th>'; 
                   }  
                   stateValue ="";
                    if(i == data.length-1){        
                        htmlString += '<th style="    border: none;    ">  </th>';                   
                        htmlString += '<th style="    border: none;   ">  </th>';
                       }
                    }
                    
                    htmlString += '<th style="    border: none;   ">  </th>';
                    htmlString +='<th rowspan="4" style="cursor:none;">TOTAL </th>';
                    htmlString +='</tr>';
                    htmlString +='<tr>';
                    htmlString +='<th style="text-align: center;  " class=" auto">Territory</th>'
                    
                    currState = data[0].State;
                    currterr = data[0].State+data[0].Distributor_Territory;
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    let distriValue = data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                        
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                            distriValue = data[i].Distributor_Territory;
                        }
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                             htmlString += '<th rowspan="3"> TOTAL </th>';
                            currState = data[i].State;
                        }
                            if(distriValue != ""){
                                htmlString += '<th style="border-right: hidden;""> <a>'+data[i].Distributor_Territory + '</a></th>';
                            }else{
                                htmlString += '<th style="    border: none;"></th>'
                            }
                          distriValue = "";
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none;    ">  </th>'; 
                            htmlString += '<th style="    border: none; ">  </th>'; 
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                          
                          }
                    }
                    htmlString +='<tr> <th style="text-align: center;     " class=" auto"> &nbsp;&nbsp;&nbsp;&nbsp; Distributers &nbsp;&nbsp;&nbsp;&nbsp;</th>';
                    currterr = data[0].State+data[0].Distributor_Territory;
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    for(let i=0; i < data.length; i++){
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th> </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th rowspan="0"> TOTAL </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none;    ">  </th>'; 
                            htmlString += '<th rowspan="0"> TOTAL </th>';                           
                          }
                       
                    }
                    htmlString +='<tr> <th style="text-align: center;     " class=" auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Up" id="partTerryDownId" onClick="partDitributDrillDown(\'' + serSecDrill + '\')"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp;</th>';
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    for(let i=0; i < data.length; i++){
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th rowspan="0"> TOTAL </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                          htmlString += '<th> <a>'+data[i].DistrictName + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th rowspan="0"> TOTAL </th>';                           
                          }
                       
                    }



                }
            }
            else{
            if(currentPage == "Territory"){
                drillStatus='terryLevel'
                singleSection = true
                singleStateValue = data[0].State;
                singleTerryValue = data[0].Distributor_Territory
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="    text-align: center;" class=" auto">State</th><th style="  text-align: center;" colspan="'+(data.length+1)+'">'+data[1].State+'</th></tr> <tr> <th style="cursor:none;text-align: center;     " class=" auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px; " title = "Drill Top" id="partDistryDownId" onClick="partStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a onClick="partDitributDrillDown(\'' + data[i].Distributor_Territory + '\')">'+data[i].Distributor_Territory + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            }
            else if(currentPage == "Distributers"){
                drillStatus = "distryLevel"
                singleSection = true
                singleStateValue = data[0].State;
                singleTerryValue = data[0].Distributor_Territory;
                singleDistyValue = data[0].DistributorID;
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="    text-align: center;" class=" auto">State</th><th style="  text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr>'; 
                htmlString +='<tr><th style="    text-align: center;" class=" auto">Territory</th><th style="  text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor_Territory+'</th></tr> <tr> <th style="cursor:none;text-align: center;     " class=" auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px; " title = "Drill Top" id="partDistryDownId" onClick="partStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a onClick="partDistictDrillDataFromApi(\'' + data[i].DistributorID + '\')">'+data[i].Distributor + '</a></th>';
                } 
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            } else if(currentPage == "District"){
                drillStatus = "districtLevel"
                singleSection = true
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="    text-align: center;" class=" auto">State</th><th style="  text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr>'; 
                htmlString +='<tr><th style="    text-align: center;" class=" auto">Territory</th><th style="  text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor_Territory+'</th></tr>';
                htmlString += '<tr><th style="    text-align: center;" class=" auto">Territory</th><th style="  text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor+'</th></tr><tr> <th style="cursor:none;text-align: center;     " class=" auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px; " title = "Drill Top" id="partDistryDownId" onClick="partStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th>'+data[i].DistrictName + '</a></th>';
                } 
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            } 
        }

        }
        else{
            if(currentPage == "State"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead> <tr> <th style="text-align: center; " class=" auto"> Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partTerryDownId" onClick="partTerryDrillDown()"></i> &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="partTerryDrillDown(\'' + serSecDrill + '\')"></i> </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th style="   min-width: 12vw;"> <a onClick="partTerryDrillDown(\'' + data[i].State + '\')">'+data[i].State + '</a></th>';
                }
                htmlString +='<th style="cursor:none;min-width:12vw">TOTAL</th>';
            }
            else if(currentPage == "Territory"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center; " class=" auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="partStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partDistryDownId" onClick="partDistyOnlyDrillDataFromApi()"></i> </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].Distributor_Territory + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>'; 
            }
            else if(currentPage == "Distributers"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center; " class=" auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="partTerryDrillDown()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partDistryDownId" onClick="partDistictOnlyDrillDataFromApi()"></i>  </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>'; 
            }
            else if(currentPage == "District"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center; " class=" auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="partDistyOnlyDrillDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp; </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].DistrictName + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            }
           
        }

        htmlString +='</tr><thead><tbody>'
    
        if(dataSum[0].Potential != null){
            htmlString +='<tr><td class=" auto">Addressability</td>';
            currState = data[0].State;
            let currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            let tt=0;
            let dd=0;
            let ds=0;
            for(let i=0; i < data.length; i++){

                let exactValue = data[i].Potential; 
                if(exactValue == null){
                    exactValue=0;
                }

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Potential) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }   

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }                 

                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Potential) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                    }
                }
               
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Potential) + '</td></tr>';    
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Primary_Sales != null){
            htmlString +='<tr><td class=" auto">Sales</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Primary_Sales) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++
                    }
                 } 

                let exactValue = data[i].Primary_Sales; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Primary_Sales) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                    }
                }
            }

            htmlString +='<td> '+numberFormatter(dataSum[0].Primary_Sales) + '</td></tr>';
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Penetration != null){
            htmlString +='<tr><td class=" auto">Market Share %</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Penetration) + '%</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }


                let exactValue = data[i].Penetration; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+convertValueInPersent(exactValue) + '%</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Penetration) + '%</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                    }
                }
            }

            htmlString +='<td> '+convertValueInPersent(dataSum[0].Penetration) + '%</td></tr>';
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Distributor_Count != null){
            htmlString +='<tr><td class=" auto"># Distributors</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Distributor_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].Distributor_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Distributor_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Distributor_Count) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Retailer_Count != null){
            htmlString +='<tr><td class=" auto"># Retailers</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
                
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Retailer_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 } 

                let exactValue = data[i].Retailer_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Retailer_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Retailer_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Retailer_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Retailer_Count) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].sku_Lt_100 != null){
            htmlString +='<tr><td class=" auto"># Retailers Buying less than 100 parts</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
                
                       
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].sku_Lt_100) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_Lt_100) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_Lt_100) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_Lt_100) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_Lt_100) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_Lt_100) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                 
                let exactValue = data[i].sku_Lt_100; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].sku_Lt_100) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_Lt_100) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_Lt_100) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].sku_Lt_100) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].sku_bw_101_500 != null){
           htmlString +='<tr><td class=" auto"># Retailers Buying 101-500 parts</td>';
           currState = data[0].State;
           currterry = data[0].State+data[0].Distributor_Territory;
           currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].sku_bw_101_500) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_bw_101_500) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_bw_101_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_bw_101_500) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_bw_101_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_bw_101_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                 
                let exactValue = data[i].sku_bw_101_500; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].sku_bw_101_500) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_bw_101_500) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_bw_101_500) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].sku_bw_101_500) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].sku_gt_500 != null){
            htmlString +='<tr><td class=" auto"># Retailers Buying more than 500 parts</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
         
                
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].sku_gt_500) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_gt_500) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_gt_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_gt_500) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_gt_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_gt_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].sku_gt_500; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].sku_gt_500) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].sku_gt_500) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].sku_gt_500) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].sku_gt_500)+ '</td></tr>';
    }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].SKU_Count != null){
            htmlString +='<tr><td class=" auto"># Unique SKUs sold</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 } 

                let exactValue = data[i].SKU_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].SKU_Count) + '</td></tr>';
         }
        
         tt=0;
         dd=0;
         ds=0;
        if(dataSum[0].Avg_Part_Per_Invoice != null){
            htmlString +='<tr><td class=" auto">Avg.Parts per invoice</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
            
                
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Avg_Part_Per_Invoice) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Avg_Part_Per_Invoice) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Avg_Part_Per_Invoice) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }


                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Avg_Part_Per_Invoice) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Avg_Part_Per_Invoice) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Avg_Part_Per_Invoice) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
 
                let exactValue = data[i].Avg_Part_Per_Invoice; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';
                

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Avg_Part_Per_Invoice) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Avg_Part_Per_Invoice) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Avg_Part_Per_Invoice) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Avg_Part_Per_Invoice)+ '</td></tr>';
        }


    //     tt=0;
    //     dd=0;
    //     ds=0;
    //    if(dataSum[0].SKU_Count_Bajaj != null){
    //        htmlString +='<tr><td class=" auto"># Unique items bought From Bajaj</td>'
    //        currState = data[0].State;
    //        currterry = data[0].State+data[0].Distributor_Territory;
    //        currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
    //        for(let i=0; i < data.length; i++){
           
               
    //            if(districtLevelTotal){
    //                if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
    //                    htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Count_Bajaj) + '</td>';
    //                    currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
    //                    ds++;
    //                }
    //            }

    //            if(districtLevelTotal){
    //                if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
    //                    htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count_Bajaj) + '</td>';
    //                    currterry = data[i].State+data[i].Distributor_Territory;
    //                    dd++;
    //                }
    //            }

    //            if(districtLevelTotal){
    //                if(currState.toLowerCase() != (data[i].State).toLowerCase()){
    //                    htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count_Bajaj) + '</td>';
    //                    currState = data[i].State;
    //                    tt++;
    //                }
    //            }


    //             if(distrubuteLevelTotal){
    //                if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
    //                    htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count_Bajaj) + '</td>';
    //                    currterry = data[i].State+data[i].Distributor_Territory;
    //                    dd++;
    //                }
    //             }

    //             if(distrubuteLevelTotal){
    //                if(currState.toLowerCase() != (data[i].State).toLowerCase()){
    //                    htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count_Bajaj) + '</td>';
    //                    currState = data[i].State;
    //                    tt++;
    //                }
    //             }

    //             if(secondLevelTotal){
    //                if(currState.toLowerCase() != (data[i].State).toLowerCase()){
    //                    htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count_Bajaj) + '</td>';
    //                    currState = data[i].State;
    //                    tt++;
    //                }
    //             }

    //            let exactValue = data[i].SKU_Count_Bajaj; 
    //            if(exactValue == null){
    //                exactValue=0;
    //            }
    //            htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';
               

    //            if(districtLevelTotal){
    //                if(i == data.length-1){
    //                    htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Count_Bajaj) + '</td>';
    //                }
    //            }

    //            if(distrubuteLevelTotal){
    //                if(i == data.length-1){
    //                    htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count_Bajaj) + '</td>';
    //                }
    //            }

    //            if(secondLevelTotal){
    //                if(i == data.length-1){
    //                    htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count_Bajaj) + '</td>';
    //                }
    //            }
    //        }
    //        htmlString +='<td> '+numberFormatter(dataSum[0].SKU_Count_Bajaj)+ '</td></tr>';
    //    }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].RT_lt_100 != null){
            htmlString +='<tr><td class=" auto">Number / Value of parts with MRP less than Rs. 100</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].RT_lt_100) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_lt_100) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_lt_100)  +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_lt_100) +  '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_lt_100)  +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_lt_100) +  '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_lt_100) +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_lt_100) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_lt_100) +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_lt_100) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_lt_100) +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_lt_100) +  '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 } 

                let exactValue = data[i].RT_lt_100; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) +' / '+ numberFormatter(data[i].sale_RT_lt_100) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].RT_lt_100) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_lt_100) +  '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_lt_100) +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_lt_100) +  '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_lt_100) +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_lt_100) +  '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].RT_lt_100)  +' / '+ numberFormatter(dataSum[0].sale_RT_lt_100) +   '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].RT_101_500 != null){
            htmlString +='<tr><td class=" auto"> Number / Value of parts with MRP from Rs. 101 - 500</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].RT_101_500) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_101_500) +  '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_101_500) +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_101_500) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_101_500) +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_101_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_101_500)  +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_101_500) +  '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_101_500)  +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_101_500) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_101_500)   +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_101_500) +  '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].RT_101_500; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) +' / '+ numberFormatter(data[i].sale_RT_101_500) +  '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].RT_101_500) +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_101_500) +  '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_101_500)  +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_101_500) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_101_500) +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_101_500) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].RT_101_500) +' / '+ numberFormatter(dataSum[0].sale_RT_101_500) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].RT_gt_500 != null){
            htmlString +='<tr><td class=" auto">Number / Value of parts with MRP from Rs. 501 & more</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
            
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].RT_gt_500)  +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_gt_500) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_gt_500)  +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_gt_500) +  '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_gt_500)  +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_gt_500) +   '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_gt_500)   +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_gt_500) +   '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_gt_500)  +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_gt_500) +  '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_gt_500)  +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_gt_500) +  '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].RT_gt_500; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)   +' / '+ numberFormatter(data[i].sale_RT_gt_500) +  '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].RT_gt_500)  +' / '+ numberFormatter(dataDistrictSum[ds].sale_RT_gt_500) +  '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].RT_gt_500)  +' / '+ numberFormatter(dataDistrySum[dd].sale_RT_gt_500) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].RT_gt_500)  +' / '+ numberFormatter(dataTerrySum[tt].sale_RT_gt_500) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].RT_gt_500) +' / '+ numberFormatter(dataSum[0].sale_RT_gt_500) + '</td></tr>';  
        }
        htmlString +='</tbody></table>'
    }
    $("#retailerStateLoader").css('display', 'none');
    $("#attributesTableId").css('display', 'block');
    $('#attributesTableId').empty();
    state='';
    //dirllTypeView=''
    secondLevelTotal = false;
    distrubuteLevelTotal = false;
    districtLevelTotal = false;
    data= null
    dataSum= null
    currentPage= null
    dataTerrySum = null
    if (htmlString == '') {
        $('#attributesTableId').append("<tr ><td class='noDataTd' colspan='14'>No Data</td></tr>")
    } else {
        $('#attributesTableId').append(htmlString);
    }
    
}

