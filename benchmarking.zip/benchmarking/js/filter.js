//callIndiaFilterOptions();  
function callIndiaFilterOptions() {
    $.ajax({
        url: getApiDomain(),
        type: "POST",
        data: JSON.stringify({ filter: "Initial_Filter_Options_V1" }),
        success: (function (data) {
            let filterData = data.data.data;
            const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            stateMeta = filterData[1][0].StateMeta;
            if (stateMeta != '') {
                stateMeta = stateMeta.toUpperCase();
            }
            idMeta = filterData[2][0].IdMeta;
            //YEAR SELECT
            $("#monthDependantComboId").empty();
            $("#monthFilter").empty();
            $("#yearFilter").empty();
            let yearIndex;
            let yearUniqArr = [];
            let firstYearVal = filterData[0].length > 0 ? filterData[0][filterData[0].length - 1].FiscalYear : "";
            for (let i = 0, yearArr = filterData[0]; i < yearArr.length; i++) {
                let selected = '';
                yearIndex = yearUniqArr.findIndex(obj => obj.FiscalYear == yearArr[i].FiscalYear);
                if (yearIndex == -1) {
                    yearUniqArr.push({ Fiscal_Year_Full: yearArr[i].Fiscal_Year_Full, FiscalYear: yearArr[i].FiscalYear });
                }
                $("#monthDependantComboId").append("<option class='" + yearArr[i].FiscalYear + "' value='" + (yearArr[i].Month_Name).trim() + "'>" + (yearArr[i].Month_Name).trim() + "</option>")
                selected = "";
               // var d = new Date();
                // var n = d.getMonth() - 1;
                // if (monthNames[n] == (yearArr[i].Month_Name).trim()) {
                if (parseInt("2") == parseInt(yearArr[i].month_num)) {
                selected = "selected";
                }
                if (firstYearVal == yearArr[i].FiscalYear) {
                    $("#monthFilter").append("<option value='" + (yearArr[i].Month_Name).trim() + "' " + selected + ">" + (yearArr[i].Month_Name).trim() + "</option>")
                }
            }
            $('#monthFilter').multiselect({
                allSelectedText: 'All',
                numberDisplayed: 1,
                nonSelectedText: 'All',
                includeSelectAllOption: true,
                enableFiltering: true,
                enableCaseInsensitiveFiltering: true
            });
            //YEAR SELECT
            for (let i = 0; i < yearUniqArr.length; i++) {
                let selected = '';
              //  if (yearUniqArr[i].FiscalYear == "FY20-21") {
                if (i == yearUniqArr.length - 1) {
                    selected = "selected";
                }
                $("#yearFilter").append("<option " + selected + " value='" + yearUniqArr[i].FiscalYear + "'>" + yearUniqArr[i].FiscalYear + "</option>")
            }
            pupulatingAllFilter();
        }),
        error: (function (err) {
            console.log(err);
        })
    });
}
let defaultSelected =false;
let currentPage = '';
let yearMonthDataObj;
let defaultStateSelected;
function pupulatingAllFilter() {
    if (yearMonthDataObj) {
        yearMonthDataObj.abort();
        yearMonthDataObj = null;
    }
    let yearData = $("#yearFilter").val();
    let monthDataNum = $("#monthFilter").val();

    let yearMonth = [];
    yearMonth.push({ dataType: "String", key: 'Year', value: yearData.toString() });
    yearMonth.push({ dataType: "String", key: 'Month', value: monthDataNum.toString() });

    if (stateMeta != '') {
        yearMonth.push({ dataType: "String", key: 'State', value: stateMeta.toString() });
        storeSelectedFilter(stateMeta.toString(), "stateFilter");
    }
    if (idMeta != '') {
        yearMonth.push({ dataType: "String", key: 'distributorID', value: idMeta.toString() });
        storeSelectedFilter(idMeta.toString(), "distributorFilter");
    }
    
    if(stateMeta == ''){
         defaultSelected =true;
         defaultStateSelected =['GUJARAT', 'MADHYA PRADESH', 'PUNJAB', 'TAMIL NADU', 'WEST BENGAL'];
        yearMonth.push({ dataType: "String", key: 'State', value: defaultStateSelected.toString() });
        storeSelectedFilter(defaultStateSelected.toString(), "stateFilter");
    }


    yearMonthDataObj = $.ajax({
        url: getApiDomain(),
        type: "POST",
        data: JSON.stringify({ 'filter': "[Filter_Options_For_BenchMarking_V1_backup_h5]", 'chartDataForms': yearMonth }),
        success: (function (data) {
            let filterData = data.data.data;
            $(".loaderFil").css("display", "none");
            populateFilterCombo(filterData, '');
            yearMonthDataObj = null;
        }),
        error: (function (err) {
            console.log(err);
            yearMonthDataObj = null;
        })
    });
}




//ON Change Filter
$(document).on('change', '#yearFilter', function () {
    let filterName = $(this).val();
    $(this).data('options', $('#monthDependantComboId option').clone());
    var finalArr = $(this).data('options').filter('[class="' + filterName + '"]');
    let preMon = $("#monthFilter").val();
    $("#monthFilter").empty();


    var html = "";
    let selected = '';
    for (i = 0; i < finalArr.length; i++) {
        jQuery(finalArr[i]).removeAttr("class");
        selected = ''

        if (preMon.includes(finalArr[i].text)) {
            selected = 'selected';
        }

        html += "<option value='" + finalArr[i].value + "' " + selected + ">" + finalArr[i].text + "</option>"
    }
    $("#monthFilter").multiselect('destroy');
    $("#monthFilter").html(html);
    $('#monthFilter').multiselect({
        allSelectedText: 'All',
        numberDisplayed: 1,
        nonSelectedText: 'All',
        includeSelectAllOption: true,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true
    });
});

let changeFilterReqObj;
let preFilterName = '';


$(document).on("change", ".filter", debounce(function () {

    let filter_Name = this.id;
    let finalCheck = true;
    onloadFunction = false;
    if (finalCheck) {
        changeFilter = false;
        let filterValue = $(this).val();
        filtterSelected(filterValue, filter_Name);
        filterAppInsiteCall(filterValue, filter_Name);
    } else {
        dashboardRefresh();
    }
}, global_debounceTime));



let preSelectedFilterArray = [];
function storeSelectedFilter(filterValue, filter_Name) {
    let filterValLen = filter_Name === "distributorFilter" ? $("#distributorFilter").val().length : 0
    
    if ((idMeta != '' && filter_Name == 'distributorFilter') || (stateMeta != '' && filter_Name == "stateFilter") || defaultSelected) {
         defaultSelected = false;
    } else if(filterValLen === 1 || filter_Name == ''){

    }
    else {
        var notSelectedfilter = $("#" + filter_Name).find('option').not(':selected');
        let arrayOfUnselectedFilter = notSelectedfilter.map(function () {
            return this.value;
        }).get();
        if (arrayOfUnselectedFilter == 0) {
            filterValue = "";
        }
    }
    const filterKeyPresent = preSelectedFilterArray.findIndex(obj => obj.filterName == filter_Name);
    if (filterKeyPresent == -1) {
        if (filterValue != '' && filterValue.length != 0) {
            preSelectedFilterArray.push({ filterName: filter_Name, filterValue: filterValue });
        }
    } else {
        if ((idMeta != '' && filter_Name == 'distributorFilter') || (stateMeta != '' && filter_Name == "stateFilter"   && filterValue =='' )) {
        } else {
            if (filterValue == '' || filterValue.length == 0) {
                preSelectedFilterArray.splice(filterKeyPresent, 1);
            } else {
                preSelectedFilterArray[filterKeyPresent].filterValue = filterValue;
            }
        }
    }



}


// function filterRetailerReset() {
//     currentPage = "retailView"
//     filtterSelected("", "RetailerID");
// }
// function filterPartCodeReset() {
//     currentPage = "partView"
//     filtterSelected("", "PartCode");
// }

function filterPageWiseShowing(pageName) {
    onloadFunction = false;
    currentPage = pageName;
     pupulatingAllFilter();

}



function filtterSelected(filterValue, filter_Name) {
    storeSelectedFilter(filterValue, filter_Name);

    let yearData = $("#yearFilter").val();
    let monthDataNum = $("#monthFilter").val();
    let drillDownSelected = "PartCode RetailerID"

    if (filter_Name == '') {

    } else {
    if (filterValue == '' || filterValue.length == 0) {
        return;
    }
}

let stateTemp =  $("#stateFilter").val();
    let selectedFilter = [];
    selectedFilter.push({ dataType: "String", key: 'Year', value: yearData.toString() });
    selectedFilter.push({ dataType: "String", key: 'Month', value: monthDataNum.toString() });
    // if(stateTemp == "")
    //     selectedFilter.push({ dataType: "String", key: 'State', value: defaultStateSelected.toString()});
               

    for (let i = 0; i < preSelectedFilterArray.length; i++) {
        switch (preSelectedFilterArray[i].filterName) {
            case "stateFilter":
                    selectedFilter.push({ dataType: "String", key: 'State', value: preSelectedFilterArray[i].filterValue.toString() });
                 break;                
            case "territoryFilter":
                selectedFilter.push({ dataType: "String", key: 'Territory', value: preSelectedFilterArray[i].filterValue.toString() });
                break;
            case "distributorFilter":
                if (idMeta != '')
                    selectedFilter.push({ dataType: "String", key: 'distributorID', value: idMeta.toString() });
                else
                    selectedFilter.push({ dataType: "String", key: 'distributorID', value: preSelectedFilterArray[i].filterValue.toString() });
                break;
            case "partCategoryFilter":
                selectedFilter.push({ dataType: "String", key: 'PartCategory', value: preSelectedFilterArray[i].filterValue.toString() });
                break;
            case "dateFilter":
                selectedFilter.push({ dataType: "String", key: 'custom_date', value: preSelectedFilterArray[i].filterValue.toString() });
                break;

        }



    }

    //defaultStateSelected
  
    if(selectedFilter.length == 2)
    selectedFilter.push({ dataType: "String", key: 'State', value: defaultStateSelected.toString()});
    
   
    $.ajax({
        url: getApiDomain(),
        type: "POST",
        data: JSON.stringify({ 'filter': "Filter_Options_For_BenchMarking_V1_backup_h5", 'chartDataForms': selectedFilter }),
        success: (function (data) {
            let filterData = data.data.data;
            populateFilterCombo(filterData, filter_Name);

        }),
        error: (function (err) {
            console.log(err);
        })
    });

}

$(document).on('click', '.fa-eraser', function () {
    stateFilterChanged = false
    territoryFilterChanged = false
    distriFilterChanged = false
    uncheckFilter1 = true
    terryFilAppend = true;
    terryFilterUpdate = true;
    preSelectedFilterArray = [];
    pupulatingAllFilter();
    $(".loaderFil").css("display", "block");
    changeFilter = true;
});


var selectedOptions;
function populateFilterCombo(filterData, filterName) {

    filterPopulate(filterData, filterName);

    if (callIndOrAnyView) {
        if (onloadFunction) {
            generalViewChartLoad();
        } else {
            dashboardRefresh();
        }
    } else {
        callIndOrAnyView = true;
    }

}

function filterPopulate(filterData, filterName){
    //Part Category Select
    if (filterName != "partCategoryFilter") {
        let categoryIndex;
        let CategoryUniqArr = [];
        $("#partCategoryFilter").empty();
        const getCategoryIndex = preSelectedFilterArray.findIndex(obj => obj.filterName == "partCategoryFilter");
        let getCategoryFilterValue = getCategoryIndex != -1 ? preSelectedFilterArray[getCategoryIndex].filterValue : '';
        for (let i = 0, categoryArr = filterData[3]; i < categoryArr.length; i++) {
            categoryIndex = CategoryUniqArr.findIndex(obj => obj.PartCategory == categoryArr[i].PartCategory);
            if (categoryIndex == -1) {
                let selected = '';
                if (getCategoryIndex == -1 && getCategoryFilterValue == '') {
                    selected = 'selected';
                } else if (getCategoryFilterValue.includes(categoryArr[i].PartCategory)) {
                    selected = 'selected';
                }
                CategoryUniqArr.push({ PartCategory: categoryArr[i].PartCategory });
                $("#partCategoryFilter").append("<option value='" + categoryArr[i].PartCategory + "' " + selected + " >" + categoryArr[i].PartCategory + "</option>");
            }
        }
        $("#partCategoryFilter").multiselect('destroy');
        $('#partCategoryFilter').multiselect({
            allSelectedText: 'All',
            numberDisplayed: 1,
            nonSelectedText: 'All',
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true
        });
    }

    //Distributor select
    if (filterName != "distributorFilter") {
        let distributorIndex;
        let distributorUniqArr = [];
        for (let i = 0, temp = filterData[1]; i < temp.length; i++) {
            distributorIndex = distributorUniqArr.findIndex(obj => obj.Distributor == temp[i].Distributor);
            if (distributorIndex == -1 && temp[i].DistributorID != 0) {
                distributorUniqArr.push({ Distributor: temp[i].Distributor, Distri_Code: temp[i].DistributorID });
            }
        }
        $("#distributorFilter").empty();
        const getDistributorIndex = preSelectedFilterArray.findIndex(obj => obj.filterName == "distributorFilter");
        let getDistributorFilterValue = getDistributorIndex != -1 ? preSelectedFilterArray[getDistributorIndex].filterValue : '';
        for (let i = 0; i < distributorUniqArr.length; i++) {
            let selected = '';
            if (getDistributorIndex == -1 && getDistributorFilterValue == '') {
                selected = 'selected';
            } else if (getDistributorFilterValue.includes(distributorUniqArr[i].Distri_Code)) {
                selected = 'selected';
            }
            if(distributorUniqArr.length == 1 && getDistributorIndex === -1)
            $("#distributorFilter").append("<option value='' class='specialCss' selected > Select All </option>");
            else if(distributorUniqArr.length == 1)
           $("#distributorFilter").append("<option value='' class='specialCss'  > Select All </option>");
          
            $("#distributorFilter").append("<option value='" + distributorUniqArr[i].Distri_Code + "' " + selected + " >" + distributorUniqArr[i].Distributor + "</option>");

        }

        $("#distributorFilter").multiselect('destroy');
        $('#distributorFilter').multiselect({
            allSelectedText: 'All',
            numberDisplayed: 1,
            nonSelectedText: 'All',
            includeSelectAllOption: true,
            enableFiltering: true,
            includeSelectAllOption: distributorUniqArr.length > 1 ? true : false,
            enableCaseInsensitiveFiltering: true   
        });
    }

    //state
    if (filterName != "stateFilter") {
        $("#stateFilter").empty();
        const getStateIndex = preSelectedFilterArray.findIndex(obj => obj.filterName == "stateFilter");
        let getStateFilterValue = getStateIndex != -1 ? preSelectedFilterArray[getStateIndex].filterValue : '';
        for (let i = 0, temp = filterData[0]; i < temp.length; i++) {
            let selected = '';
            if (getStateIndex == -1 && getStateFilterValue == '') {
                if (i < 5)
                selected = 'selected';
            } else if (getStateFilterValue.includes(temp[i].State)) {
                selected = 'selected';
            }
            // if ($("#stateFilter").val().length >= 4) {
            //     selected = '';
            // }
            // if(selected !='selected')
            // selected = 'disabled';
            $("#stateFilter").append("<option value='" + temp[i].State + "' " + selected + " >" + temp[i].State + "</option>");
          
        }
       
        $("#stateFilter").multiselect('destroy');       
        $('#stateFilter').multiselect({
            
         onChange: function(option, checked) {
            restrictedStateFilter();
            },


            allSelectedText: 'All',
            columns: 2,
            numberDisplayed: 1,
            nonSelectedText: 'All',
            includeSelectAllOption: true,
            enableFiltering: true,
            includeSelectAllOption: false,
            enableCaseInsensitiveFiltering: true
        });
        restrictedStateFilter();
    }

    
    //Territory

    if (filterName != "territoryFilter") {
        $("#territoryFilter").empty();
        const getTerritoryIndex = preSelectedFilterArray.findIndex(obj => obj.filterName == "territoryFilter");
        let getTerriFilterValue = getTerritoryIndex != -1 ? preSelectedFilterArray[getTerritoryIndex].filterValue : '';
        for (let i = 0, territoryArr = filterData[2]; i < territoryArr.length; i++) {
            let selected = '';
            if (getTerritoryIndex == -1 && getTerriFilterValue == '') {
                selected = 'selected';
            } else if (getTerriFilterValue.includes(territoryArr[i].Distributor_Territory)) {
                selected = 'selected';
            }
            $("#territoryFilter").append("<option value='" + territoryArr[i].Distributor_Territory + "' " + selected + " >" + territoryArr[i].Distributor_Territory + "</option>");
        }
        $("#territoryFilter").multiselect('destroy');
        $('#territoryFilter').multiselect({
            allSelectedText: 'All',
            numberDisplayed: 1,
            nonSelectedText: 'All',
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true
        });
    }

    //Custome_Date   //  dateFilter
    if (filterName != "dateFilter") {
        $("#dateFilter").empty();
        const getDateIndex = preSelectedFilterArray.findIndex(obj => obj.filterName == "dateFilter");
        let getDateValue = getDateIndex != -1 ? preSelectedFilterArray[getDateIndex].filterValue : '';
        for (let i = 0, dateArr = filterData[4]; i < dateArr.length; i++) {
            let selected = '';
            if (getDateIndex == -1 && getDateValue == '') {
                selected = 'selected';
            } else if (getDateValue.includes(dateArr[i].Custom_Date)) {
                selected = 'selected';
            }
            $("#dateFilter").append("<option value='" + dateArr[i].Custom_Date + "' " + selected + " >" + dateArr[i].Custom_Date + "</option>");
        }

        $("#dateFilter").multiselect('destroy');
        $('#dateFilter').multiselect({
            allSelectedText: 'All',
            numberDisplayed: 1,
            nonSelectedText: 'All',
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true
        });

    }

}

   function restrictedStateFilter(){
         // Get selected options.
         var selectedOptions = $('#stateFilter option:selected');
 
         if (selectedOptions.length >= 5) {
             // Disable all other checkboxes.
             var nonSelectedOptions = $('#stateFilter option').filter(function() {
                 return !$(this).is(':selected');
             });

             nonSelectedOptions.each(function() {
                 var input = $('input[value="' + $(this).val() + '"]');
                 input.prop('disabled', true);
                 input.parent('li').addClass('disabled');
             });
         }
         else {
             // Enable all checkboxes.
             $('#stateFilter option').each(function() {
                 var input = $('input[value="' + $(this).val() + '"]');
                 input.prop('disabled', false);
                 input.parent('li').addClass('disabled');
             });
         }
   }