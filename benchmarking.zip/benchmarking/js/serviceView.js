exactView ='';
dirllTypeView='';
let serviceViewValue='';
let srviceStateObj;
let secondLevelTotal = false;
let serSecDrill="SecondLevel";
function serviceStateDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (srviceStateObj) {
        srviceStateObj.abort();
        srviceStateObj = null;
    }
    let currentPage = "State";
    exactView = "stateView";
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Service_View_State_Table_V2";
    srviceStateObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_State_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            serviceTotalDataApi(data,currentPage,state);
            srviceStateObj = null;
            data = null;
        }),
        error: (function (err) {
            srviceStateObj = null;
            console.log(err);
        })
    });   
}


let servicDistiBuObj;
function serviceTerryDrillDown(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (servicDistiBuObj) {
        servicDistiBuObj.abort();
        servicDistiBuObj = null;
    }
    let currentPage = "Territory";
    exactView = "territoryView";
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Service_View_Territory_Table_V2";
    servicDistiBuObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_Territory_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            serviceTotalDataApi(data,currentPage,state);
            servicDistiBuObj = null;
            data = null;
        }),
        error: (function (err) {
            servicDistiBuObj = null;
            console.log(err);
        })
    });
}

let servicTerryObj;
function serviceDitributDrillDown(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    if (servicTerryObj) {
        servicTerryObj.abort();
        servicTerryObj = null;
    }
    let currentPage = "Distributers";
    exactView = "distributerView";
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Service_View_Distributor_Table_V2";
    servicTerryObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let data = resultData.data.data[0];
            serviceTotalDataApi(data,currentPage,state);
            servicTerryObj = null;
            data = null;
        }),
        error: (function (err) {
            servicTerryObj = null;
            console.log(err);
        })
    });
}

let districtObjService;
function serviceDistrictDrillDown(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "District";
    exactView = "districtView";
    if(state == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (districtObjService) {
            districtObjService.abort();
            districtObjService = null;
        }
        let terryFilterData;
        if(state != undefined && state != "" && state != "SecondLevel"){
            terryFilterData =  createDrillDownFilterData(state,currentPage);
        }else{
            terryFilterData = createTerryFilterData();
        }
        let procedureName = "Service_View_District_Table_V2";
        districtObjService = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "Service_View_District_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                serviceTotalDataApi(data,currentPage,state)
                districtObjService = null;
                data = null;
            }),
            error: (function (err) {
                districtObjService = null;
                console.log(err);
            })
        });
}

let serviceTotalObj;
function serviceTotalDataApi(data,currentPage,state){
    if (serviceTotalObj) {
        serviceTotalObj.abort();
        serviceTotalObj = null;
    }
    let terryFilterData;
    if(state != "" && state != undefined && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage)
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Service_View_State_Total_V2";
    serviceTotalObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_State_Total_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataSum = resultData.data.data[0];

            if(state == "SecondLevel" && currentPage == "Territory"){
                territoryServiceTotalFetching(data,dataSum,currentPage,state);
            }else if(state == "SecondLevel" && currentPage == "Distributers"){
                territoryServiceTotalFetching(data,dataSum,currentPage,state);
            }else if(state == "SecondLevel" && currentPage == "District"){
                territoryServiceTotalFetching(data,dataSum,currentPage,state);
            }else{
                serviceDataToInsertTable(data,dataSum,currentPage,state);
            }
            serviceTotalObj = null;
            data = null;
        }),
        error: (function (err) {
            serviceTotalObj = null;
            console.log(err);
        })
    });
}

let sevriTerryPartObj;
function territoryServiceTotalFetching(data,dataSum,currentPage,state){
    if (sevriTerryPartObj) {
        sevriTerryPartObj.abort();
        sevriTerryPartObj = null;
    }
    let terryFilterData;
    if(state != undefined && state != "" && state != "SecondLevel"){
        terryFilterData =  createGeneralDrillDownFilterData(state,currentPage);
    }else{
        terryFilterData = createGeneralFilterData();
    }
    let procedureName = "Service_View_State_Table_V2";
    sevriTerryPartObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_State_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataTerrySum = resultData.data.data[0];
            if(state == "SecondLevel" && currentPage == "Distributers"){
                distributerServiceTotalFetching(data,dataSum,currentPage,state,dataTerrySum);
            }else if(state == "SecondLevel" && currentPage == "District"){
                distributerServiceTotalFetching(data,dataSum,currentPage,state,dataTerrySum);
            }else{
                serviceDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum);
            }
            sevriTerryPartObj = null;
            data = null;
        }),
        error: (function (err) {
            sevriTerryPartObj = null;
            console.log(err);
        })
    });

}

let distyServTotaObj;
function distributerServiceTotalFetching(data,dataSum,currentPage,state,dataTerrySum){
    if (distyServTotaObj) {
        distyServTotaObj.abort();
        distyServTotaObj = null;
    }
    let terryFilterData;
    if(state != undefined && state != "" && state != "SecondLevel"){
        terryFilterData =  createGeneralDrillDownFilterData(state,currentPage);
    }else{
        terryFilterData = createGeneralFilterData();
    }
    let procedureName = "Service_View_Territory_Table_V2";
    distyServTotaObj = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_Territory_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataDistrySum = resultData.data.data[0];
            if(state == "SecondLevel" && currentPage == "District"){
                districtServiceTotalFetching(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum);
            }else {
                serviceDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum);
            }
            distyServTotaObj = null;
            data = null;
        }),
        error: (function (err) {
            distyServTotaObj = null;
            console.log(err);
        })
    });
}

let distritServObjTotal;
function districtServiceTotalFetching(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum){
    if (distritServObjTotal) {
        distritServObjTotal.abort();
        distritServObjTotal = null;
    }
    let terryFilterData;
    if(state != undefined && state != "" && state != "SecondLevel"){
        terryFilterData =  createDrillDownFilterData(state,currentPage);
    }else{
        terryFilterData = createTerryFilterData();
    }
    let procedureName = "Service_View_Distributor_Table_V2";
    distritServObjTotal = $.ajax({
        url: getApiDomain(),
        type: 'POST',
        data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //    data: JSON.stringify({ 'filter': "Service_View_Distributor_Table_V2", 'chartDataForms': terryFilterData }),
        success: (function (resultData) {
            let dataDistrictSum = resultData.data.data[0];
            serviceDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum,dataDistrictSum);
            distritServObjTotal = null;
            data = null;
        }),
        error: (function (err) {
            distritServObjTotal = null;
            console.log(err);
        })
    });
}



let distryServiceOnlyObj;
function serviceDistyOnlyDrillDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
        if (distryServiceOnlyObj) {
            distryServiceOnlyObj.abort();
            distryServiceOnlyObj = null;
        }
        let currentPage = "Distributers";
        exactView = "distributerView";
        if(state == "SecondLevel"){
            dirllTypeView = "SecondLevel";
        }else{
            dirllTypeView='';
        }
        let terryFilterData;
        if(state != undefined && state != "" && state != "SecondLevel"){
            terryFilterData =  createDrillDownFilterData(state,currentPage);
        }else{
            terryFilterData = createTerryFilterData();
        }
        let procedureName = "Service_View_Distributor_Only_Table_V2";
        distryServiceOnlyObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "Service_View_Distributor_Only_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                serviceTotalDataApi(data,currentPage,state)
                distryServiceOnlyObj = null;
                data = null;
            }),
            error: (function (err) {
                distryServiceOnlyObj = null;
                console.log(err);
            })
        });
}


let serviceDistictOnlyObj;
function serviceDistictOnlyDrillDataFromApi(state){
    $("#retailerStateLoader").css('display', 'block');
    $("#attributesTableId").css('display', 'none');
    let currentPage = "District";
    exactView = "districtView";
    if(state == "SecondLevel"){
        dirllTypeView = "SecondLevel";
    }else{
        dirllTypeView='';
    }
        if (serviceDistictOnlyObj) {
            serviceDistictOnlyObj.abort();
            serviceDistictOnlyObj = null;
        }
        let terryFilterData;
        if(state != undefined && state != "" && state != "SecondLevel"){
            terryFilterData =  createDrillDownFilterData(state,currentPage);
        }else{
            terryFilterData = createTerryFilterData();
        }
        let procedureName = "Service_View_District_Only_Table_V2";
        serviceDistictOnlyObj = $.ajax({
            url: getApiDomain(),
            type: 'POST',
            data: JSON.stringify({ chartDataForms: terryFilterData, filter: procedureName,'filterHash' : cTageHash( procedureName + JSON.stringify(terryFilterData)),'dashboardId' : dashboardId }),
    
    //        data: JSON.stringify({ 'filter': "Service_View_District_Only_Table_V2", 'chartDataForms': terryFilterData }),
            success: (function (resultData) {
                let data = resultData.data.data[0];
                serviceTotalDataApi(data,currentPage,state)
                serviceDistictOnlyObj = null;
                data = null;
            }),
            error: (function (err) {
                serviceDistictOnlyObj = null;
                console.log(err);
            })
        });
}



function serviceDataToInsertTable(data,dataSum,currentPage,state,dataTerrySum,dataDistrySum,dataDistrictSum){
    let htmlString = '';
    if(data.length != 0){
        if(state != "" && state != undefined){
            if(state == "SecondLevel"){
                secondLevelTotal = true;
                if(currentPage == "Territory"){
                    drillStatus='terryLevel'
                    singleSection = false
                    let currState = data[0].State;
                    let stateValue = data[0].State;
                  
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="     text-align: center;" class="  auto">State</th>';
                   for(let i=0; i < data.length; i++){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th    >  </th>';
                        currState = data[i].State;
                        stateValue = data[i].State
                    }

                    if(stateValue != ""){
                        htmlString +='<th style="border-right: aliceblue; text-align: center;">'+stateValue+'</th>'; 
                    }else{
                        htmlString +='<th    ></th>'
                    }
                    stateValue = "";
                        if(i == data.length-1){
                            htmlString += '<th    >  </th>';
                          }
                    }

                    htmlString +='<th rowspan="2" style="cursor:none;">TOTAL</th></tr><tr> <th style="text-align: center;      " class="  auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="serviceStateDataFromApi()"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="serviceDitributDrillDown(\'' + serSecDrill + '\')"></i></th>';
                    currState = data[0].State;
                    for(let i=0; i < data.length; i++){
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                            htmlString += '<th> TOTAL </th>';
                            currState = data[i].State;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor_Territory + '</a></th>';
                          if(i == data.length-1){
                            htmlString += '<th> TOTAL </th>';
                          }
                    }
                    
                    
                }
				else if(currentPage == "Distributers"){
                    drillStatus = "distryLevel";
                    singleSection = false
                    let currState = data[0].State;
                    let currterr = data[0].State+data[0].Distributor_Territory;
                    distrubuteLevelTotal = true;
                    let stateValue = data[0].State;
                   
                    
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" >';
                    htmlString += '<thead>';
                    htmlString += '<tr>';
                    htmlString += '<th style="  border-right: aliceblue;text-align: center;" class="  auto">State</th>';
                   for(let i=0; i < data.length; i++){
                    if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                         htmlString += '<th style="    border: none;    ">  </th>';                      
                        currterr = data[i].State+data[i].Distributor_Territory;
                    }
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th style="    border: none;    ">  </th>';      
                        currState = data[i].State;
                        stateValue = data[i].State;
                   }
                   if(stateValue != ""){
                        htmlString +='<th  style="border-right: hidden;" text-align: center;">'+currState+'</th>'; 
                   }else{
                    htmlString +='<th style="    border: none;   "></th>'; 
                   }  
                   stateValue ="";
                        if(i == data.length-1){                          
                            htmlString += '<th style="    border: none;   ">  </th>';
                         }
                    }

                    htmlString += '<th style="    border: none;   ">  </th>';
                    htmlString +='<th rowspan="4" style="cursor:none;">TOTAL </th>';
                    htmlString +='</tr>';
                    htmlString +='<tr>';
                    htmlString +='<th style="text-align: center;   " class="  auto">Territory</th>'
                    
                    currState = data[0].State;
                    currterr = data[0].State+data[0].Distributor_Territory;
                    let distriValue = data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                        
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                            distriValue = data[i].Distributor_Territory;
                        }
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                             htmlString += '<th rowspan="3"> TOTAL </th>';
                            currState = data[i].State;
                        }
                            if(distriValue != ""){
                                htmlString += '<th style="border-right: hidden;""> <a>'+data[i].Distributor_Territory + '</a></th>';
                            }else{
                                htmlString += '<th style="    border: none;"></th>'
                            }
                          distriValue = "";
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none; ">  </th>'; 
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                          
                          }
                    }
                    htmlString +='<tr> <th style="text-align: center;      " class="  auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Up" id="partTerryDownId" onClick="serviceTerryDrillDown(\'' + serSecDrill + '\')"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="serviceDistrictDrillDown(\'' + serSecDrill + '\')"></i></th>';
                    currterr = data[0].State+data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                       
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                            
                            currterr = data[i].State+data[i].Distributor_Territory;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th rowspan="3"> TOTAL </th>';                           
                          }
                       
                    }

                }
                else if(currentPage == "District"){

                    drillStatus = "districtLevel"
                    singleSection = false
                    let currState = data[0].State;
                    let currterr = data[0].State+data[0].Distributor_Territory;
                    distrubuteLevelTotal = true;
                    districtLevelTotal = true;
                    let stateValue = data[0].State;
                    let currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                   
                    
                    htmlString +='<table id="sharedDataId" class="zui-table" border="1" >';
                    htmlString += '<thead>';
                    htmlString += '<tr>';
                    htmlString += '<th style="  border-right: aliceblue;text-align: center;" class="  auto">State</th>';
                   for(let i=0; i < data.length; i++){

                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<th style="    border: none;    ">  </th>';                      
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                   }

                    if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                         htmlString += '<th style="    border: none;    ">  </th>';                      
                        currterr = data[i].State+data[i].Distributor_Territory;
                    }
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<th style="    border: none;    ">  </th>';      
                        currState = data[i].State;
                        stateValue = data[i].State;
                   }
                   if(stateValue != ""){
                        htmlString +='<th  style="border-right: hidden;" text-align: center;">'+currState+'</th>'; 
                   }else{
                    htmlString +='<th style="    border: none;   "></th>'; 
                   }  
                   stateValue ="";
                    if(i == data.length-1){        
                        htmlString += '<th style="    border: none;    ">  </th>';                   
                        htmlString += '<th style="    border: none;   ">  </th>';
                       }
                    }
                    
                    htmlString += '<th style="    border: none;   ">  </th>';
                    htmlString +='<th rowspan="4" style="cursor:none;">TOTAL </th>';
                    htmlString +='</tr>';
                    htmlString +='<tr>';
                    htmlString +='<th style="text-align: center;   " class="  auto">Territory</th>'
                    
                    currState = data[0].State;
                    currterr = data[0].State+data[0].Distributor_Territory;
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    let distriValue = data[0].Distributor_Territory;
                    for(let i=0; i < data.length; i++){
                        
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th style="    border: none;"> </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                            distriValue = data[i].Distributor_Territory;
                        }
                        if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                             htmlString += '<th rowspan="3"> TOTAL </th>';
                            currState = data[i].State;
                        }
                            if(distriValue != ""){
                                htmlString += '<th style="border-right: hidden;""> <a>'+data[i].Distributor_Territory + '</a></th>';
                            }else{
                                htmlString += '<th style="    border: none;"></th>'
                            }
                          distriValue = "";
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none;    ">  </th>'; 
                            htmlString += '<th style="    border: none; ">  </th>'; 
                            htmlString += '<th rowspan="3"> TOTAL </th>';
                          
                          }
                    }
                    htmlString +='<tr> <th style="text-align: center;      " class="  auto"> &nbsp;&nbsp;&nbsp;&nbsp; Distributers &nbsp;&nbsp;&nbsp;&nbsp;</th>';
                    currterr = data[0].State+data[0].Distributor_Territory;
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    for(let i=0; i < data.length; i++){
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th> </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                        if(currterr.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                            htmlString += '<th rowspan="0"> TOTAL </th>';
                            currterr = data[i].State+data[i].Distributor_Territory;
                        }
                          htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th style="    border: none;    ">  </th>'; 
                            htmlString += '<th rowspan="0"> TOTAL </th>';                           
                          }
                       
                    }
                    htmlString +='<tr> <th style="text-align: center;      " class="  auto"><i class="fa fa-shield fa-flip-vertical" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Up" id="partTerryDownId" onClick="serviceDitributDrillDown(\'' + serSecDrill + '\')"></i> &nbsp;&nbsp;&nbsp;&nbsp; Attributes &nbsp;&nbsp;&nbsp;&nbsp;</th>';
                    currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
                    for(let i=0; i < data.length; i++){
                        if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                            htmlString += '<th rowspan="0"> TOTAL </th>';
                            currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        }
                          htmlString += '<th> <a>'+data[i].DistrictName + '</a></th>';
                          
                          if(i == data.length-1){
                            htmlString += '<th rowspan="0"> TOTAL </th>';                           
                          }
                       
                    }



                }
            }
            else{
            if(currentPage == "Territory"){
                drillStatus = "terryLevel"
                singleSection = true;
                singleStateValue = data[0].State;
                singleTerryValue = data[0].Distributor_Territory
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="     text-align: center;" class="  auto">State</th><th style="    text-align: center;" colspan="'+(data.length+1)+'">'+data[1].State+'</th></tr> <tr> <th style="cursor:none;text-align: center;      " class="  auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;  " title = "Drill Top" id="partDistryDownId" onClick="serviceStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a onClick="serviceDitributDrillDown(\'' + data[i].Distributor_Territory + '\')">'+data[i].Distributor_Territory + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            }
            else if(currentPage == "Distributers"){
                drillStatus = "distryLevel"
                singleSection = true;
                singleStateValue = data[0].State;
                singleTerryValue = data[0].Distributor_Territory;
                singleDistyValue = data[0].DistributorID;
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="     text-align: center;" class="  auto">State</th><th style="    text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr>'; 
                htmlString +='<tr><th style="     text-align: center;" class="  auto">Territory</th><th style="    text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor_Territory+'</th></tr> <tr> <th style="cursor:none;text-align: center;      " class="  auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;  " title = "Drill Top" id="partDistryDownId" onClick="serviceStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a onClick="serviceDistrictDrillDown(\'' + data[i].DistributorID + '\')">'+data[i].Distributor + '</a></th>';
                } 
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            } else if(currentPage == "District"){
                drillStatus = "districtLevel"
                singleSection = true
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead><tr><th style="     text-align: center;" class="  auto">State</th><th style="    text-align: center;" colspan="'+(data.length+1)+'">'+data[0].State+'</th></tr>'; 
                htmlString +='<tr><th style="     text-align: center;" class="  auto">Territory</th><th style="    text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor_Territory+'</th></tr>';
                htmlString += '<tr><th style="     text-align: center;" class="  auto">Territory</th><th style="    text-align: center;" colspan="'+(data.length+1)+'">'+data[0].Distributor+'</th></tr><tr> <th style="cursor:none;text-align: center;      " class="  auto"><i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;  " title = "Drill Top" id="partDistryDownId" onClick="serviceStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;</th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th>'+data[i].DistrictName + '</a></th>';
                } 
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            } 
        }

        }
        else{
            if(currentPage == "State"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" ><thead> <tr> <th style="text-align: center;  " class="  auto"> Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partTerryDownId" onClick="serviceTerryDrillDown()"></i> &nbsp;&nbsp;&nbsp;&nbsp; <i class="fa fa-shield" style="cursor: pointer;font-size: 17px;" title = "Second level Drill Down" id="partTerryDownId" onClick="serviceTerryDrillDown(\'' + serSecDrill + '\')"></i> </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th style="    min-width: 12vw;"> <a onClick="serviceTerryDrillDown(\'' + data[i].State + '\')">'+data[i].State + '</a></th>';
                }
                htmlString +='<th style="cursor:none; min-width: 12vw">TOTAL</th>';
            }
            else if(currentPage == "Territory"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center;  " class="  auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="serviceStateDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partDistryDownId" onClick="serviceDistyOnlyDrillDataFromApi()"></i> </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].Distributor_Territory + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>'; 
            }
            else if(currentPage == "Distributers"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center;  " class="  auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="serviceTerryDrillDown()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp;<i class="fa fa-angle-double-down" style="cursor: pointer;font-size: 17px;" title = "Drill Down" id="partDistryDownId" onClick="serviceDistictOnlyDrillDataFromApi()"></i>  </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].Distributor + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>'; 
            }
            else if(currentPage == "District"){
                drillStatus = ""
                singleSection = false
                htmlString +='<table id="sharedDataId" class="zui-table" border="1" > <thead> <tr> <th style="text-align: center;  " class="  auto"> <i class="fa fa-angle-double-up" style="cursor: pointer;font-size: 17px;" title = "Drill Up" id="partDistryDownId" onClick="serviceDistyOnlyDrillDataFromApi()"></i> &nbsp;&nbsp; Attributes &nbsp;&nbsp; </th>';
                for(let i=0; i < data.length; i++){
                    htmlString += '<th> <a>'+data[i].DistrictName + '</a></th>';
                }
                htmlString +='<th style="cursor:none;">TOTAL</th>';
            }
           
        }

        htmlString +='</tr><thead><tbody>'
    
        if(dataSum[0].Potential != null){
            htmlString +='<tr><td class="  auto">Addressability</td>';
            currState = data[0].State;
            let currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            let tt=0;
            let dd=0;
            let ds=0;
            for(let i=0; i < data.length; i++){

                let exactValue = data[i].Potential; 
                if(exactValue == null){
                    exactValue=0;
                }
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Potential) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }
                 
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                 

                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Potential) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Potential) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Potential) + '</td>';
                    }
                }
               
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Potential) + '</td></tr>';    
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Primary_Sales != null){
            htmlString +='<tr><td class="  auto">Sales</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Primary_Sales) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }
  
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                        currState = data[i].State;
                        tt++
                    }
                 } 

                let exactValue = data[i].Primary_Sales; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Primary_Sales) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Primary_Sales) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Primary_Sales) + '</td>';
                    }
                }
            }

            htmlString +='<td> '+numberFormatter(dataSum[0].Primary_Sales) + '</td></tr>';
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Penetration != null){
            htmlString +='<tr><td class="  auto">Market Share %</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Penetration) + '%</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                } 
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 } 

                let exactValue = data[i].Penetration; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+convertValueInPersent(exactValue) + '%</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrictSum[ds].Penetration) + '%</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataDistrySum[dd].Penetration) + '%</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+convertValueInPersent(dataTerrySum[tt].Penetration) + '%</td>';
                    }
                }
            }

            htmlString +='<td> '+convertValueInPersent(dataSum[0].Penetration) + '%</td></tr>';
        }
        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Distributor_Count != null){
            htmlString +='<tr><td class="  auto"># Distributors</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
              
              
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Distributor_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }
                
                
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }


                let exactValue = data[i].Distributor_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Distributor_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Distributor_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Distributor_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Distributor_Count) + '</td></tr>';
        }

        // tt=0;
        // dd=0;
        // ds=0;
        // if(dataSum[0].Dealer_Count != null){
        //     htmlString +='<tr><td class="  auto"># Dealers</td>'
        //     currState = data[0].State;
        //     currterry = data[0].State+data[0].Distributor_Territory;
        //     currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
        //     for(let i=0; i < data.length; i++){
             
        //         if(districtLevelTotal){
        //             if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Dealer_Count) + '</td>';
        //                 currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
        //                 ds++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Count) + '</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //         }


        //          if(distrubuteLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Count) + '</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //          }

        //          if(distrubuteLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }

        //          if(secondLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }

        //         let exactValue = data[i].Dealer_Count; 
        //         if(exactValue == null){
        //             exactValue=0;
        //         }
        //         htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
        //         if(districtLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Dealer_Count) + '</td>';
        //             }
        //         }

        //         if(distrubuteLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Count) + '</td>';
        //             }
        //         }

        //         if(secondLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Count) + '</td>';
        //             }
        //         }
        //     }
        //     htmlString +='<td> '+numberFormatter(dataSum[0].Dealer_Count) + '</td></tr>';
        // }

        // tt=0;
        // dd=0;
        // ds=0;
        // if(dataSum[0].Dealer_Sales != null){
        //     htmlString +='<tr><td class="  auto">Dealer Contribution To Sales(Primary)</td>'
        //     currState = data[0].State;
        //     currterry = data[0].State+data[0].Distributor_Territory;
        //     currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
        //     for(let i=0; i < data.length; i++){

        //         if(districtLevelTotal){
        //             if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Dealer_Sales) + '</td>';
        //                 currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
        //                 ds++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Sales) + '</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //         }

        //         if(districtLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Sales) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //         }

        //          if(distrubuteLevelTotal){
        //             if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Sales) + '</td>';
        //                 currterry = data[i].State+data[i].Distributor_Territory;
        //                 dd++;
        //             }
        //          }

        //          if(distrubuteLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Sales) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          }

        //          if(secondLevelTotal){
        //             if(currState.toLowerCase() != (data[i].State).toLowerCase()){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Sales) + '</td>';
        //                 currState = data[i].State;
        //                 tt++;
        //             }
        //          } 

        //         let exactValue = data[i].Dealer_Sales; 
        //         if(exactValue == null){
        //             exactValue=0;
        //         }
        //         htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
        //         if(districtLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Dealer_Sales) + '</td>';
        //             }
        //         }

        //         if(distrubuteLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Dealer_Sales) + '</td>';
        //             }
        //         }

        //         if(secondLevelTotal){
        //             if(i == data.length-1){
        //                 htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Dealer_Sales) + '</td>';
        //             }
        //         }
        //     }
        //     htmlString +='<td> '+numberFormatter(dataSum[0].Dealer_Sales) + '</td></tr>';
        // }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Total_Service_Volume != null){
           htmlString +='<tr><td class="  auto"># Total Service Volume</td>';
           currState = data[0].State;
           currterry = data[0].State+data[0].Distributor_Territory;
           currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Total_Service_Volume) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Service_Volume) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Service_Volume) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }
                
                
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Service_Volume) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Service_Volume) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Service_Volume) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 } 

                let exactValue = data[i].Total_Service_Volume; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Total_Service_Volume) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Service_Volume) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Service_Volume) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Total_Service_Volume) + '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].SKU_Count != null){
            htmlString +='<tr><td class="  auto"># SKU bought by Service Center</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){

                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }

                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 } 

                let exactValue = data[i].SKU_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].SKU_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].SKU_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].SKU_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].SKU_Count)+ '</td></tr>';
    }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Paid_Service_per != null){
            htmlString +='<tr><td class="  auto">Paid service</td>';
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
              
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Paid_Service_per) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Paid_Service_per) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Paid_Service_per) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }
  
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Paid_Service_per) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Paid_Service_per) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                
                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Paid_Service_per) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
 
                let exactValue = data[i].Paid_Service_per; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue) + '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Paid_Service_per) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Paid_Service_per) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Paid_Service_per) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Paid_Service_per) + '</td></tr>';
         }
        
         tt=0;
         dd=0;
         ds=0;
        if(dataSum[0].Service_Per_BikePopulation != null){
            htmlString +='<tr><td class="  auto">Service volume / Total Vehicle Population</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
            
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Service_Per_BikePopulation) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Service_Per_BikePopulation) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Service_Per_BikePopulation) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }
  
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Service_Per_BikePopulation) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Service_Per_BikePopulation) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
                
                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Service_Per_BikePopulation) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }
 
                let exactValue = data[i].Service_Per_BikePopulation; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';                

                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Service_Per_BikePopulation) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Service_Per_BikePopulation) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Service_Per_BikePopulation) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Service_Per_BikePopulation)+ '</td></tr>';
        }

        tt=0;
        dd=0;
        ds=0;
        if(dataSum[0].Total_Vehicle_Count != null){
            htmlString +='<tr><td class="  auto">Total Vehicle Population</td>'
            currState = data[0].State;
            currterry = data[0].State+data[0].Distributor_Territory;
            currDistry = data[0].State+data[0].Distributor_Territory+data[0].DistributorID;
            for(let i=0; i < data.length; i++){
               
                if(districtLevelTotal){
                    if(currDistry.toLowerCase() != (data[i].State+data[i].Distributor_Territory+data[i].DistributorID).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Total_Vehicle_Count) + '</td>';
                        currDistry = data[i].State+data[i].Distributor_Territory+data[i].DistributorID;
                        ds++;
                    }
                }

                if(districtLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Vehicle_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                }

                if(districtLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                }  
                 if(distrubuteLevelTotal){
                    if(currterry.toLowerCase() != (data[i].State+data[i].Distributor_Territory).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Vehicle_Count) + '</td>';
                        currterry = data[i].State+data[i].Distributor_Territory;
                        dd++;
                    }
                 }

                 if(distrubuteLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                 if(secondLevelTotal){
                    if(currState.toLowerCase() != (data[i].State).toLowerCase()){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                        currState = data[i].State;
                        tt++;
                    }
                 }

                let exactValue = data[i].Total_Vehicle_Count; 
                if(exactValue == null){
                    exactValue=0;
                }
                htmlString += '<td> '+numberFormatter(exactValue)+ '</td>';
                
                if(districtLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrictSum[ds].Total_Vehicle_Count) + '</td>';
                    }
                }

                if(distrubuteLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataDistrySum[dd].Total_Vehicle_Count) + '</td>';
                    }
                }

                if(secondLevelTotal){
                    if(i == data.length-1){
                        htmlString += '<td> '+numberFormatter(dataTerrySum[tt].Total_Vehicle_Count) + '</td>';
                    }
                }
            }
            htmlString +='<td> '+numberFormatter(dataSum[0].Total_Vehicle_Count)+ '</td></tr>';
        }
        htmlString +='</tbody></table>'
    }
    $("#retailerStateLoader").css('display', 'none');
    $("#attributesTableId").css('display', 'block');
    $('#attributesTableId').empty();
    state='';
    //dirllTypeView=''
    secondLevelTotal = false;
    distrubuteLevelTotal = false;
    districtLevelTotal = false;
    data= null
    dataSum= null
    currentPage= null
    dataTerrySum = null
    if (htmlString == '') {
        $('#attributesTableId').append("<tr ><td class='noDataTd' colspan='14'>No Data</td></tr>")
    } else {
        $('#attributesTableId').append(htmlString);
    }
}
